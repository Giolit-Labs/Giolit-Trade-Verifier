#pragma once
// Worker processes for the phases that race each other (see
// giolit::verifyProgram): a forked child computes, writes its findings to a
// pipe as JSON lines, and is killed once another phase has decided.
#include <signal.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <unistd.h>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <string>

namespace vtask {

// The process's current virtual size in MB (-1: unknown).
inline long virtualSizeMb() {
    std::ifstream in("/proc/self/statm");
    long pages = -1;
    if (!(in >> pages)) return -1;
    return pages * (sysconf(_SC_PAGESIZE) / 1024) / 1024;
}

// Forks a worker whose write end is `*writeFd` (the parent keeps `*readFd`).
// In the child: it dies with the parent, and its address space may grow by at
// most `extraMemoryMb` beyond what it inherited (0: the inherited limit).
// Returns the child's pid in the parent, 0 in the child, -1 on failure (no
// fds are left open then).
inline pid_t forkWorker(int* readFd, int* writeFd, long extraMemoryMb) {
    int fds[2];
    if (pipe(fds) != 0) return -1;
    std::cout.flush();
    std::cerr.flush();
    std::fflush(nullptr);
    const pid_t parent = getpid();
    std::cout.flush();   // the child must not inherit (and later write again) what the caller printed
    std::cerr.flush();
    std::fflush(nullptr);
    pid_t pid = fork();
    if (pid < 0) {
        close(fds[0]);
        close(fds[1]);
        return -1;
    }
    if (pid == 0) {
        close(fds[0]);
        prctl(PR_SET_PDEATHSIG, SIGKILL);
        if (getppid() != parent) _exit(0);  // the parent is already gone
        if (extraMemoryMb > 0) {
            long mb = virtualSizeMb();
            rlimit cur{};
            if (mb > 0 && getrlimit(RLIMIT_AS, &cur) == 0) {
                rlim_t want = static_cast<rlim_t>(mb + extraMemoryMb) * 1024 * 1024;
                if (cur.rlim_cur == RLIM_INFINITY || cur.rlim_cur > want) {
                    rlimit lim{want, cur.rlim_max};
                    setrlimit(RLIMIT_AS, &lim);
                }
            }
        }
        *writeFd = fds[1];
        *readFd = -1;
        return 0;
    }
    close(fds[1]);
    *readFd = fds[0];
    *writeFd = -1;
    return pid;
}

// Writes all of `s` (stops early when the pipe is full in non-blocking mode,
// or the reader is gone).
inline void writeAll(int fd, const std::string& s) {
    const char* p = s.data();
    size_t n = s.size();
    while (n > 0) {
        ssize_t w = ::write(fd, p, n);
        if (w <= 0) return;
        p += w;
        n -= static_cast<size_t>(w);
    }
}

}
