#pragma once
// The backend's answer for a vtask::Task: the second half of the standard
// interface. Everything refers to task nodes and slots; front ends map it
// back to source terms using Node::slots / SourceLoc.
#include "vtask/Task.hpp"
#include <map>
#include <string>
#include <vector>

namespace vtask {

enum class Verdict { Safe, Unsafe, Unknown };

// One node's invariant: a conjunction of guards over that node's slots.
// lhs ≡ residue (mod modulus), over a node's slots.
struct Congruence {
    Linear lhs;
    long long modulus = 1, residue = 0;
};

struct NodeInvariant {
    NodeId node = 0;
    bool unreachable = false;     // the invariant is `false`
    std::vector<Guard> conjuncts; // empty and !unreachable: `true`
    // A disjunctive invariant: the states lie in one of these conjunctions;
    // `conjuncts` is then their hull. Empty: `conjuncts` alone.
    std::vector<std::vector<Guard>> disjuncts;
    // Per disjunct (aligned with `disjuncts`; may be empty): its congruences.
    std::vector<std::vector<Congruence>> disjunctCongruences;
};

// How the invariants prove safety. Forward: they over-approximate the reachable states and exclude every violation.
// ForwardBackward: they over-approximate the reachable states; a backward analysis showed that none of those states
// can lead to a violation. Backward: they over-approximate the states that can lead to a violation, and exclude the
// initial states. Exhaustive: every reachable state was enumerated (no invariants).
enum class ProofKind { None, Forward, ForwardBackward, Backward, Exhaustive };
const char* toString(ProofKind k);

struct Certificate {
    std::vector<NodeInvariant> invariants;
    ProofKind kind = ProofKind::None;
};

// A counterexample: a derivation tree of concrete tuples ending at @error.
struct CexStep {
    NodeId node = 0;
    std::vector<long long> values;
    EdgeId edge = -1;             // edge that produced it (-1: seed)
    std::vector<int> parents;     // indices into Counterexample::steps
    long long skippedIterations = 0;  // > 0: reached by accelerating a cycle this many times
};

struct Counterexample {
    std::vector<CexStep> steps;   // steps.back() reaches the error node
    std::string text;             // human-readable summary
};

// v6: the verdict of one check (Task::checks). Proven: no execution violates
// it (under the task's model). Violated: a concrete execution does (cex).
// Unknown: neither within the budget (cause says why).
enum class CheckStatus { Proven, Violated, Unknown, Unreachable };
struct CheckResult {
    int checkId = 0;
    CheckStatus status = CheckStatus::Unknown;
    std::string how;          // "whole-program proof", "invariant", "own proof", "counterexample", ...
    std::string cause;        // Unknown: why
    Counterexample cex;       // Violated
    double seconds = 0;
    // Proven: the proof's invariants at the clock-cycle boundary (the nodes where a cycle starts), and their kind
    Certificate proof;
};
const char* toString(CheckStatus s);

struct Result {
    Verdict verdict = Verdict::Unknown;
    std::vector<CheckResult> checks;  // v6 per-check mode: one per Task::checks entry
    std::string unknownCause;
    Certificate certificate;      // Safe
    Counterexample cex;           // Unsafe
    std::map<std::string, double> stats;
};

const char* toString(Verdict v);

}
