#pragma once
// The verification task: a graph over integer slot vectors, the interface between the front end and the engines.
//
// Node n holds tuples of n.arity integers. An edge fires on one tuple per source node; their concatenation (in `from`
// order) is the joint vector x. The edge is enabled when every guard holds (lhs(x) <= bound); the target tuple is then
// y[a.lhs] = a.rhs(x) for each assignment, and an arbitrary integer for havoc assignments and for target slots no
// assignment mentions. The property: no tuple ever reaches the error node.
// Every edge describes its source semantics exactly or is marked `imprecise`; counterexamples are only reported
// along exact edges.
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <string>
#include <vector>

namespace vtask {

constexpr const char* kTaskFormat = "vtask/2";

using NodeId = int;
using EdgeId = int;

struct Linear {
    std::map<int, double> coeffs;
    double constant = 0;
};

struct Guard {
    Linear lhs;
    double bound = 0;
    bool implied = false;   // already implied by the exact values (an accelerator relation): for the prover only
};

// The exact value of a havoc the linear form cannot express (bit operations, division, wrap-around, binary64
// arithmetic). The F* operators work on encoded binary64 values (vtask/FloatOps.hpp, in the order of fp::FOp).
struct ConcreteExpr {
    enum class Op { Const, Slot, Add, Sub, Mul, Div, Mod, BitAnd, BitOr, BitXor, Shl, Shr, Neg, BitNot, LNot,
                    FAdd, FSub, FMul, FDiv, FNeg, FMin, FMax, FSqrt, FExp, FLog, FFromInt, FFloor, FCeil, FRound, FTrunc, FLt, FLe, FEq, FFinite, FToFix };
    Op op = Op::Const;
    long long value = 0;
    int slot = -1;
    std::vector<ConcreteExpr> args;
};
std::optional<long long> evalConcrete(const ConcreteExpr& e, const std::vector<long long>& slots);

struct Assign {
    int lhs = 0;
    bool havoc = false;
    Linear rhs;
    std::shared_ptr<const ConcreteExpr> concrete;
    bool determined = false;   // `concrete` fully determines the value
};

struct SourceLoc {
    std::string file;
    int line = 0;
    int column = 0;
    bool valid() const { return line > 0; }
};

struct SlotInfo {
    std::string name;
    int bitWidth = 0;   // 0: mathematical integer
    bool isSigned = true;
};

enum class CheckKind : unsigned char {
    Assert,               // concurrent assertion (safety)
    Immediate,            // immediate assertion
    Cover,                // reached: covered
    Liveness,             // s_eventually: the goal is reachable (a witness, not a proof)
    Strong,               // safety part of a property with strong obligations
    LivenessAntecedent,   // companions of Liveness / Strong
    LivenessBound,
    LivenessCycle,
    Trivial,              // no instance in the model: holds
    Unsupported,
};
const char* toString(CheckKind k);
CheckKind checkKindFrom(const std::string& s);
inline bool isCompanion(CheckKind k) {
    return k == CheckKind::LivenessAntecedent || k == CheckKind::LivenessBound || k == CheckKind::LivenessCycle;
}

struct Check {
    int id = 0;
    CheckKind kind = CheckKind::Assert;
    std::string name;      // the property's hierarchical name
    std::string message;   // source text, or why it is unsupported
    SourceLoc loc;
    std::string scope;
    bool reachable = true;
};

enum class NodeRole { Predicate, Entry, Error, Unknown };
enum class EdgeKind { Fact, Transition, Query, Skip };
// Where a node lies: the start of a clock cycle (one per cycle), an input drawn at its first use inside a cycle, the
// entry of a function of the model (the target of call edges), or anywhere else.
enum class Region : unsigned char { Model, CycleStart, Input, FunctionEntry };

struct Node {
    NodeId id = 0;
    std::string name;
    NodeRole role = NodeRole::Predicate;
    Region region = Region::Model;
    int arity = 0;
    std::vector<SlotInfo> slots;   // empty, or one entry per slot
    SourceLoc loc;
    std::vector<Linear> hints;     // template directions worth trying, a nonzero constant c: the bound coeffs <= -c (never semantics)
    std::vector<int> splitHints;   // slots worth splitting disjunctions on first, e.g. pending flags (never semantics)
};

struct Edge {
    EdgeId id = 0;
    std::vector<NodeId> from;   // empty: fires from @entry
    NodeId to = 0;
    std::vector<Guard> guards;
    std::vector<Assign> assigns;
    EdgeKind kind = EdgeKind::Transition;
    bool imprecise = false;
    std::string approxReason;
    bool overflowBranch = false;   // a wrapped case of a machine-arithmetic split (a hint for affine analyses)
    int checkId = -1;              // query edges: the check this violation belongs to
    SourceLoc loc;
};

// The liveness obligations of one property: each is violated on a run where its pending slot stays set while every
// recurrence slot is set infinitely often (and every fairness slot of the design too).
struct LivenessObligation {
    std::string pending;
    std::vector<std::string> recurrence;
};
struct LivenessCheck {
    int bound = -1, cycle = -1;   // the companion checks (k-liveness counter, lasso)
    std::vector<LivenessObligation> obligations;
};

// What the hardware front end tells the engines and the driver about the model.
// A design signal as the user names it (relative to the top module), with the model variable that holds it.
struct HwSignal {
    std::string name, cname;
    int width = 1;
    bool isSigned = false, isInput = false, isClock = false, isRegister = false;
    bool isReal = false;                // holds an encoded binary64 (vtask/FloatOps.hpp)
    int arrayLen = 0, arrayLower = 0;   // a memory: arrayLen words
};

// A numeric bound of an assertion that can be tightened: a comparison in an asserted position (`count <= DEPTH`) or
// the upper end of a delay window (`##[1:3]`). Tightening it by k replaces [offset, offset + length) of `file` with
// `replacement(k)`; the largest k for which the assertion still holds is its safety margin.
struct BoundAtom {
    enum class Kind { Value, Window } kind = Kind::Value;
    std::string property;     // the property's name
    std::string text;         // the comparison or the delay, as written
    std::string file;         // absolute path
    size_t offset = 0, length = 0;
    std::string original;     // the text replaced (Value: the bound operand; Window: the delay)
    int sign = -1;            // Value: the operand becomes ((original) - k) (sign -1) or ((original) + k) (sign +1)
    long long windowMin = 0, windowMax = 0;   // Window: ##[min:max]
    long long allowed = 0;    // the size of the allowed range (values, or cycles of the window); 0: not known
    long long maxShift = 0;   // the largest k worth trying
    std::string replacement(long long k) const {
        if (kind == Kind::Window) {   // the text after the last ':' is the window's upper end
            size_t colon = original.rfind(':'), close = original.find(']', colon == std::string::npos ? 0 : colon);
            if (colon == std::string::npos) return original;
            return original.substr(0, colon + 1) + std::to_string(windowMax - k) + (close == std::string::npos ? "" : original.substr(close));
        }
        return "((" + original + ") " + (sign < 0 ? "- " : "+ ") + std::to_string(k) + ")";
    }
};

struct HardwareInfo {
    std::string top;
    std::vector<BoundAtom> bounds;
    std::vector<HwSignal> signals;
    std::map<std::string, std::string> stateNames;   // auxiliary model state (sampled values, monitor state) -> its meaning
    std::set<std::string> flags;                     // auxiliary model state that is 0 or 1
    std::vector<LivenessCheck> liveness;
    std::vector<std::string> fairness;      // slots set in a cycle where a fairness condition held
    bool fairnessIgnored = false;           // a liveness assumption was not modelled: no lasso is a counterexample
    std::set<std::string> auxiliary;        // counters only the k-liveness checks read: not part of the state
    std::map<int, int> depth;               // check -> last cycle in which its (initial) assertion can fail
    std::map<std::string, int> property;    // property name -> catalogue index (per-property models)
    std::vector<std::string> notes;
    bool overApproximate = false;           // an assumption was dropped: violations are only candidates
};

struct Task {
    std::string format = kTaskFormat;
    std::string sourceFile;
    std::vector<Node> nodes;   // nodes[i].id == i
    std::vector<Edge> edges;   // edges[i].id == i
    NodeId entry = -1, error = -1, unknown = -1;
    bool overApproximate = false;
    std::map<std::string, long> stats;   // statistics only, never decisions
    std::vector<Check> checks;           // checks[i].id == i
    HardwareInfo hw;
};

std::vector<std::string> validate(const Task& t);

}
