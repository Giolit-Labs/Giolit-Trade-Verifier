#pragma once
// Binary64 values in integer slots: the encoder and decoder (the IEEE-754 bit pattern), and the floating-point
// operators of ConcreteExpr, shared by every evaluator so that all engines compute the same bits.
//
// Semantics: round-to-nearest-even binary64 as C/C++ `double` on x86-64 (SSE2, no fast-math, no FMA contraction);
// exp/log from the host libm; min/max as std::min/std::max; conversions to integers saturate at +-2^62 and map NaN to 0
// (a non-finite value is reported by the FFinite checks the front end places before every conversion).
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <optional>
#include <string>

namespace vtask::fp {

// the operators, in the order they follow LNot in ConcreteExpr::Op
enum class FOp {
    Add, Sub, Mul, Div, Neg, Min, Max, Sqrt, Exp, Log, FromInt, Floor, Ceil, Round, Trunc, Lt, Le, Eq, Finite, ToFix
};
constexpr int kCount = 20;
inline int arity(FOp o) {
    switch (o) {
        case FOp::Neg: case FOp::Sqrt: case FOp::Exp: case FOp::Log: case FOp::FromInt: case FOp::Floor: case FOp::Ceil:
        case FOp::Round: case FOp::Trunc: case FOp::Finite: return 1;
        default: return 2;
    }
}
// operators whose result is an integer (the others give an encoded binary64)
inline bool integerResult(FOp o) {
    switch (o) {
        case FOp::Floor: case FOp::Ceil: case FOp::Round: case FOp::Trunc: case FOp::Lt: case FOp::Le: case FOp::Eq:
        case FOp::Finite: case FOp::ToFix: return true;
        default: return false;
    }
}
// operators whose operands are integers (FromInt; ToFix's second operand, the scale exponent, is checked apart)
inline bool integerOperand(FOp o, int k) { return o == FOp::FromInt || (o == FOp::ToFix && k == 1); }

inline double dec(long long k) {
    double d;
    std::memcpy(&d, &k, sizeof d);
    return d;
}
inline long long enc(double d) {
    long long k;
    std::memcpy(&k, &d, sizeof k);
    return k;
}

constexpr double kSat = 4611686018427387904.0;   // 2^62
inline long long saturate(double v) {
    if (std::isnan(v)) return 0;
    if (v >= kSat) return (long long)1 << 62;
    if (v <= -kSat) return -((long long)1 << 62);
    return (long long)v;   // v is already integral
}

// the shortest decimal that reads back as the same binary64 (traces, reports)
inline std::string text(double d) {
    if (std::isnan(d)) return "NaN";
    if (std::isinf(d)) return d > 0 ? "inf" : "-inf";
    char buf[40];
    for (int p = 1; p <= 17; ++p) {
        std::snprintf(buf, sizeof buf, "%.*g", p, d);
        if (std::strtod(buf, nullptr) == d) break;
    }
    return buf;
}

// volatile-free, contraction-free: every operation is one rounding
inline std::optional<long long> apply(FOp o, long long a, long long b) {
    const double x = dec(a), y = dec(b);
    switch (o) {
        case FOp::Add: return enc(x + y);
        case FOp::Sub: return enc(x - y);
        case FOp::Mul: return enc(x * y);
        case FOp::Div: return enc(x / y);
        case FOp::Neg: return enc(-x);
        case FOp::Min: return enc(y < x ? y : x);
        case FOp::Max: return enc(x < y ? y : x);
        case FOp::Sqrt: return enc(std::sqrt(x));
        case FOp::Exp: return enc(std::exp(x));
        case FOp::Log: return enc(std::log(x));
        case FOp::FromInt: return enc((double)a);
        case FOp::Floor: return saturate(std::floor(x));
        case FOp::Ceil: return saturate(std::ceil(x));
        case FOp::Round: return saturate(std::round(x));
        case FOp::Trunc: return saturate(std::trunc(x));
        case FOp::Lt: return x < y ? 1 : 0;
        case FOp::Le: return x <= y ? 1 : 0;
        case FOp::Eq: return x == y ? 1 : 0;
        case FOp::Finite: return std::isfinite(x) ? 1 : 0;
        case FOp::ToFix: {   // floor(x * 2^b): NaN saturates high (a range check then fails)
            if (b < -1074 || b > 1074) return std::nullopt;
            if (std::isnan(x)) return (long long)1 << 62;
            return saturate(std::floor(std::ldexp(x, (int)b)));
        }
    }
    return std::nullopt;
}

}
