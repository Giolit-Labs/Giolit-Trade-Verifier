#pragma once
// Model data in design terms: the design signal a model slot holds, and a counterexample as signal values per clock
// cycle. Shared by the console output and the report.
#include "vtask/Result.hpp"
#include "vtask/Task.hpp"
#include <cctype>
#include <cstdlib>
#include <map>
#include <string>
#include <vector>

namespace vtask {

// The design signal a model slot holds ("" for temporaries): s<scope>_<a>__<b> is a.b, <signal>__B<k> bit k of it,
// <signal>__E<i> word i of a scalarised memory.
inline std::string displayName(const std::string& cname, int* bit = nullptr) {
    if (bit) *bit = -1;
    size_t bpos = cname.rfind("__B");
    if (bpos != std::string::npos && bpos + 3 < cname.size()) {
        bool digits = true;
        for (size_t i = bpos + 3; i < cname.size(); ++i) digits = digits && std::isdigit((unsigned char)cname[i]);
        if (digits) {
            std::string base = displayName(cname.substr(0, bpos));
            if (!base.empty() && bit) *bit = std::atoi(cname.c_str() + bpos + 3);
            return bit ? base : std::string();
        }
    }
    size_t epos = cname.rfind("__E");
    if (epos != std::string::npos && epos + 3 < cname.size()) {
        std::string idx = cname.substr(epos + 3);
        bool ok = true;
        for (size_t i = 0; i < idx.size(); ++i) ok = ok && (std::isdigit((unsigned char)idx[i]) || (i == 0 && idx[i] == 'm'));
        if (ok) {
            std::string base = displayName(cname.substr(0, epos));
            if (base.empty()) return "";
            return base + "[" + (idx[0] == 'm' ? "-" + idx.substr(1) : idx) + "]";
        }
    }
    if (cname.size() < 3 || cname[0] != 's' || !std::isdigit((unsigned char)cname[1])) return "";
    if (cname.find('@') != std::string::npos) return "";
    if (cname.size() > 3 && cname.compare(cname.size() - 3, 3, "__n") == 0) return "";
    size_t u = cname.find('_');
    if (u == std::string::npos) return "";
    for (size_t i = 1; i < u; ++i)
        if (!std::isdigit((unsigned char)cname[i])) return "";
    std::string r = cname.substr(u + 1), out;
    for (size_t i = 0; i < r.size(); ++i) {
        if (r[i] == '_' && i + 1 < r.size() && r[i + 1] == '_') {
            out += '.';
            ++i;
        } else out += r[i];
    }
    return out;
}

// The signal values per clock cycle along a counterexample: the steps in a cycle-start region open a cycle, inputs
// drawn later in the cycle belong to it.
inline std::vector<std::map<std::string, long long>> cyclesOf(const vtask::Task& t, const vtask::Counterexample& cex) {
    std::vector<std::map<std::string, long long>> cycles;
    bool inCycle = false;
    for (auto& st : cex.steps) {
        if (st.node < 0 || st.node >= (int)t.nodes.size()) continue;
        const vtask::Node& nd = t.nodes[st.node];
        std::map<std::string, long long> vals;
        for (size_t k = 0; k < nd.slots.size() && k < st.values.size(); ++k) {
            int bit = -1;
            std::string n = displayName(nd.slots[k].name, &bit);
            if (n.empty()) continue;
            if (bit < 0) vals[n] = st.values[k];
            else if (st.values[k]) vals[n] += (long long)1 << bit;
            else vals.emplace(n, 0);
        }
        if (nd.region == vtask::Region::Input) {
            if (!cycles.empty())
                for (auto& [k, v] : vals) cycles.back()[k] = v;
            inCycle = false;
        } else if (nd.region == vtask::Region::CycleStart) {
            if (!inCycle) {
                cycles.push_back({});
                inCycle = true;
            }
            for (auto& [k, v] : vals) cycles.back()[k] = v;
        } else inCycle = false;
    }
    return cycles;
}

}
