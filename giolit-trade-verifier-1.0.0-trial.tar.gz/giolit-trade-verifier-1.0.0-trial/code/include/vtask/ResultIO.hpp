#pragma once
// Results and counterexamples as JSON: how engine processes report to the race and to the driver.
#include "vtask/Json.hpp"
#include "vtask/Result.hpp"

namespace vtask {
json::Value toJson(const Result& r);
Result resultFromJson(const json::Value& v);
json::Value toJson(const Counterexample& c);
Counterexample counterexampleFromJson(const json::Value& v);
json::Value toJson(const CheckResult& c);
json::Value toJson(const Certificate& c);
Certificate certificateFromJson(const json::Value& v);
CheckResult checkResultFromJson(const json::Value& v);
}
