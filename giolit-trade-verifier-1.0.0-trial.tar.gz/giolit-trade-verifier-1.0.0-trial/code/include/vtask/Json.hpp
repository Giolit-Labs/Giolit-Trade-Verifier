#pragma once
// Minimal JSON value, reader and writer for the task/result exchange format.
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace vtask::json {

struct Error : std::runtime_error {
    using std::runtime_error::runtime_error;
};

class Value {
public:
    enum class Type { Null, Bool, Number, String, Array, Object };

    Value() = default;
    Value(std::nullptr_t) {}
    Value(bool b) : type_(Type::Bool), bool_(b) {}
    Value(double d) : type_(Type::Number), num_(d) {}
    Value(int i) : type_(Type::Number), num_(i) {}
    Value(long i) : type_(Type::Number), num_((double)i) {}
    Value(long long i) : type_(Type::Number), num_((double)i), isInt_(true), int_(i) {}
    Value(const char* s) : type_(Type::String), str_(s) {}
    Value(std::string s) : type_(Type::String), str_(std::move(s)) {}

    static Value array() { Value v; v.type_ = Type::Array; return v; }
    static Value object() { Value v; v.type_ = Type::Object; return v; }

    Type type() const { return type_; }
    bool isNull() const { return type_ == Type::Null; }

    bool asBool() const;
    double asDouble() const;
    long long asInt() const;
    const std::string& asString() const;
    const std::vector<Value>& items() const;
    const std::map<std::string, Value>& fields() const;

    // Object access: `at` throws when missing, `get` returns null.
    const Value& at(const std::string& key) const;
    const Value& get(const std::string& key) const;
    bool has(const std::string& key) const;

    Value& operator[](const std::string& key);  // makes this an object
    void push(Value v);                         // makes this an array

    std::string dump() const;
    static Value parse(const std::string& text);

private:
    void write(std::string& out) const;

    Type type_ = Type::Null;
    bool bool_ = false;
    double num_ = 0;
    bool isInt_ = false;
    long long int_ = 0;
    std::string str_;
    std::vector<Value> arr_;
    std::map<std::string, Value> obj_;
};

}
