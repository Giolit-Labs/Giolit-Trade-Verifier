#pragma once
// Giolit Trading Risk Verifier -- the report library (libgiolit_report): the evidence bundle for one verified
// specification.
//
//   certificate.pdf              every constraint PROVEN: the certificate of formal verification, with the proofs
//                                (inductive invariants over the trading state at the step boundary) and the headroom
//   violation-report.pdf         a constraint is VIOLATED: the violating runs, event by event
//   verification-report.pdf      otherwise: what is proved, what is open and why
//   certificate.json (+ .sig)    the result statement, signed with the licensee's key
//   signer-credential.json (+ .sig), giolit-master-key.txt, verify_certificate.py   the chain of trust
//   runs/<constraint>.{txt,json,fix,csv}   every violating or witness run: text, JSON, FIX 4.4 messages, market path
//   results.json, proof.json, the specification, reproduce.sh, README.txt
#include "giolit/Api.hpp"
#include "giolit/Trade.hpp"
#include <string>
#include <utility>
#include <vector>

namespace giolit {

// What a bundle certifies: every constraint proved, a constraint violated, or neither.
enum class ReportVerdict { Verified, Failed, Incomplete };
inline const char* toString(ReportVerdict v) {
    return v == ReportVerdict::Verified ? "VERIFIED" : v == ReportVerdict::Failed ? "VIOLATIONS" : "INCOMPLETE";
}

struct ReportRequest {
    std::string specFile;                   // the specification as verified
    std::string outDir;                     // the bundle folder (created)
    std::string issuedTo;                   // optional: who the certificate is for
    std::vector<std::string> commandLine;   // the verification command (reproduce.sh)
    std::string engineVersion;              // e.g. "1.0.0"
    std::string engineBuild;                // e.g. a git revision
    std::string consoleOutput;              // saved as verifier-output.txt
};

struct ReportOutcome {
    ReportVerdict verdict = ReportVerdict::Incomplete;
    std::string documentId;
    std::string pdfPath;
    bool pdfOk = false;       // false: lualatex failed (the .tex and .log are kept)
    bool signedByLicensee = false;
    std::string message;      // why unsigned, or what failed
};

// Writes the bundle. Throws AccessDenied without a valid token.
GIOLIT_API ReportOutcome writeReport(const AccessToken& token, const TradeResult& result, const ReportRequest& request);

// A proof in the specification's terms: the invariant at the step boundary as relations over the trading state
// (position, open_qty(buy), strategy state, ...); `legend` explains the model's own names it uses.
struct TradeProof {
    vtask::ProofKind kind = vtask::ProofKind::None;
    std::vector<std::string> relations;
    std::vector<std::pair<std::string, std::string>> legend;
    std::string note;   // what the relations leave out, if anything
};
GIOLIT_API TradeProof describeProof(const AccessToken& token, const ConstraintResult& constraint, const std::map<std::string, std::string>& facts);

}
