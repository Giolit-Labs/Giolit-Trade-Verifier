#pragma once
// Giolit Trading Risk Verifier -- the trading API (libgiolit_frontend: lowerSpec; libgiolit_trade: verifySpec).
//
// A GTSL specification (assumptions, protocol, market, strategy parameters and rules, risk controls, constraints) is
// compiled into a transition system, one step per trading event, and every constraint is proved for every reachable
// behaviour or refuted by a concrete event sequence.
//
//   giolit::TokenGrant g = giolit::acquireToken();
//   giolit::TradeResult r = giolit::verifySpec(g.token, "desk.gts", giolit::TradeOptions{});
//   for (const giolit::ConstraintResult& c : r.constraints) ... c.verdict, c.trace (a violating run), c.proof
#include "giolit/Api.hpp"
#include "vtask/Result.hpp"
#include "vtask/Task.hpp"
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace giolit {

// How orders are represented. Slots: K order slots with their full lifecycle; exact for runs with at most K live
// orders at a time (every violation it finds is real). Aggregate: per side the total open quantity and the number of
// live orders, plus one watched order chosen among all orders; proofs hold for any number of orders.
enum class OrderModel { Slots, Aggregate };

struct SpecOptions {
    OrderModel model = OrderModel::Slots;
    int slots = 4;                            // K, for OrderModel::Slots
    std::string only;                         // only this constraint (its cone of influence); empty: all
    bool sanity = true;                       // the automatic sanity checks (assumptions, rules, controls, triggers)
    bool constraints = true;                  // the constraints and targets (false: the sanity checks alone)
    bool controlsOnly = false;                // also set by `mode controls_only;` in the specification
    std::map<std::string, std::string> parameters;   // -P NAME=VALUE: overrides a strategy parameter
    bool traceState = false;                  // keep every displayed variable in the model (full traces; slower proofs)
    std::map<std::string, long long> tighten; // constraint -> k: its limit tightened by k (risk headroom)
    // optimization: the objective (objective { minimize|maximize EXPR; }) bounded by a check "#objective":
    // objective <= bound (upper) or objective >= bound, at the session's close (or at every step without a session)
    bool objectiveCheck = false, objectiveUpper = true;
    long long objectiveBound = 0;
    // risk controls whose condition needs products or real arithmetic accept or reject any order (an over-
    // approximation for proofs: fewer intermediate nodes)
    bool coarseControls = false;
    // encodings for the provers (ghost state; frontends/trade/src/Encodings.hpp): "" none, "auto" the best-ranked kind,
    // or kinds such as "int.onehot,bool.pair"
    std::string encodings;
};

// Throws InputError (with the line) when the specification is not valid GTSL, AccessDenied without a valid token.
GIOLIT_API vtask::Task lowerSpec(const AccessToken& token, const std::string& path, const SpecOptions& options);
// The GTSL the specification's `import "x.gbind";` statements generate from the customer's code (--import-only).
GIOLIT_API std::string importedSpecText(const AccessToken& token, const std::string& path);

enum class Verdict {
    Proven,          // holds on every run (any number of orders)
    ProvenBounded,   // holds on every run with at most K live orders; not proved beyond
    Violated,        // a run violates it (trace)
    Feasible,        // a `feasible` target or sanity check: a run reaches it (trace)
    Infeasible,      // ... no run reaches it (proved)
    Undecided,       // neither within the time budget (cause says why)
    Unsupported
};
inline const char* toString(Verdict v) {
    switch (v) {
        case Verdict::Proven: return "PROVEN";
        case Verdict::ProvenBounded: return "PROVEN*";
        case Verdict::Violated: return "VIOLATED";
        case Verdict::Feasible: return "FEASIBLE";
        case Verdict::Infeasible: return "INFEASIBLE";
        case Verdict::Unsupported: return "UNSUPPORTED";
        default: return "UNDECIDED";
    }
}

enum class CheckRole {
    Constraint,   // constraints { name: ... } -- must hold
    Target,       // constraints { name: feasible ... } -- should be reachable (Q3)
    Sanity        // automatic: the specification is not vacuous (assumptions consistent, rules fire, controls act)
};

// One order as the trace shows it.
struct TraceOrder {
    int id = 0;            // 1, 2, ... in the order of creation
    std::string side;      // BUY / SELL
    long long qty = 0, cum = 0, price = -1;   // price in ticks; -1: market order
    std::string state;     // PendingNew, New, PartFilled, Filled, PendingCancel, Cancelled, Rejected
    std::string venue;     // several venues: where the order was sent ("" with one venue)
    std::string symbol;    // several symbols: the order's symbol ("" with one symbol)
};

// One step of a run: the event, the actions the strategy took in response, and the state after the step.
struct TraceStep {
    std::string event;                          // e.g. "Fill O1 100 @ 30001"
    std::vector<std::string> actions;           // e.g. "NewOrder O2 BUY 100 @ 30000", "risk control max_qty rejected ..."
    std::map<std::string, long long> state;     // position, open_qty(buy), market.bid, strategy state, ... after the step
    std::map<std::string, double> reals;        // the strategy's real (binary64) state and parameters after the step
    std::vector<TraceOrder> orders;             // live and just-finished orders after the step
};

struct ConstraintResult {
    std::string name;
    CheckRole role = CheckRole::Constraint;
    std::string text;                 // as written (sanity checks: what is checked)
    int line = 0;
    Verdict verdict = Verdict::Undecided;
    std::string method;               // how it was decided (engine and order model)
    std::string cause;                // Undecided: why
    double seconds = 0;
    std::vector<TraceStep> trace;     // Violated / Feasible: steps 1..n; trace[0] is the initial state
    std::shared_ptr<const vtask::Task> task;   // the model `proof` refers to
    vtask::Certificate proof;         // Proven: the invariants at the step boundary
    // risk headroom (after addHeadroom): how far the limit can be tightened and still hold on every run
    bool hasHeadroom = false;
    std::string bounded;              // the bounded expression as written, e.g. "position"
    std::string limitText;            // the limit as written, e.g. "max_position" or "1000"
    bool upper = true;                // an upper limit (<=, <) or a lower one (>=, >)
    long long margin = 0;             // the largest tightening proved (model units: shares, ticks, money units)
    long long limit = 0, worst = 0;   // when the limit is a plain number: it, and the worst value any run reaches
    bool worstExact = false;          // tightening by margin + 1 is violated (a run reaches `worst`)
    double relative = -1;             // margin / |limit|, -1: not known
    int stars = 0;                    // Giolit Risk Resilience Score of this limit, 1..5 (0: not rated)
};

struct TradeOptions {
    SpecOptions lower;
    double seconds = 60;              // total time budget
    bool raceModels = true;           // slot and aggregate models in parallel (the aggregate model proves for any
                                      // number of orders; its violations are confirmed in the slot model)
    bool aggregateOnly = false;       // the aggregate model alone (proofs only; its violations stay candidates)
    bool certificates = false;        // keep each proof's invariants (for the certificate)
};

// The objective over all behaviours: for each direction, a value some run reaches and a bound every run respects.
struct ObjectiveRange {
    bool known = false;
    long long reached = 0;            // a run reaches this value (witness)
    bool hasReached = false;
    long long bound = 0;              // proved: no run goes beyond it
    bool hasBound = false;
    std::vector<TraceStep> witness;   // the run that reaches `reached`
};
struct ObjectiveResult {
    bool present = false;
    std::string text;                 // the objective as written
    bool minimize = true;
    std::string unit;                 // what the numbers count (money units, shares, ...)
    ObjectiveRange best, worst;       // the best and the worst value over all runs (by the objective's direction)
};

struct TradeResult {
    std::string spec;                 // the specification's name
    std::vector<ConstraintResult> constraints;   // constraints and feasibility targets, in specification order
    std::vector<ConstraintResult> sanity;        // the automatic sanity checks
    std::vector<std::string> notes;   // about the model (e.g. K, controls-only mode, over-approximations)
    std::map<std::string, std::string> facts;   // units for outputs: #tick, #money (decimal, in #currency), #currency,
                                                // #timeunit (seconds), #symbol, #open/#close (time units)
    int slots = 4;
    bool controlsOnly = false;
    double seconds = 0;
    int resilienceStars = 0;          // after addHeadroom: the smallest score of the limits (0: none rated)
    ObjectiveResult objective;        // after optimizeObjective
};

// Verifies every constraint of the specification. Throws InputError when it is not valid GTSL, AccessDenied without
// a valid token.
GIOLIT_API TradeResult verifySpec(const AccessToken& token, const std::string& path, const TradeOptions& options);

// Risk headroom: for every proven constraint of the form `always X <= L` (or >=, <, >, abs(X) <= L), the worst value
// X reaches on any run, found by tightening L and proving again (bisection), within `seconds` in all.
GIOLIT_API void addHeadroom(const AccessToken& token, const std::string& path, const TradeOptions& options, TradeResult& result,
                            double seconds = 60);

// Conformance: a FIX log (drop copy, execution reports, market data; tag=value with SOH or '|' between fields)
// replayed through the specification's model. Every message the model says cannot happen (a venue behaviour the
// protocol or the assumptions exclude), every order or cancel the strategy sent that its rules would not send (or, in
// controls-only mode, that the risk controls would reject), every order the rules would send that the log does not
// show, and every constraint the observed run violates.
struct ConformIssue {
    enum class Kind { Impossible, UnexpectedOrder, MissingOrder, ControlMismatch, Violation, Unmapped, Note } kind = Kind::Note;
    int message = 0;          // 1-based index of the message in the log (0: the end of the log)
    int line = 0;             // its line in the log file
    std::string text;         // the message, summarised
    std::string why;          // what the specification says
};
inline const char* toString(ConformIssue::Kind k) {
    switch (k) {
        case ConformIssue::Kind::Impossible: return "IMPOSSIBLE";
        case ConformIssue::Kind::UnexpectedOrder: return "UNEXPECTED";
        case ConformIssue::Kind::MissingOrder: return "MISSING";
        case ConformIssue::Kind::ControlMismatch: return "CONTROLS";
        case ConformIssue::Kind::Violation: return "VIOLATION";
        case ConformIssue::Kind::Unmapped: return "UNMAPPED";
        default: return "NOTE";
    }
}
struct ConformResult {
    int messages = 0, replayed = 0;                       // messages read, and replayed through the model
    std::vector<ConformIssue> issues;
    std::vector<std::map<std::string, long long>> states; // the model's state after each replayed message (model names)
    std::vector<std::string> events;                      // what each replayed message was, for the model
    std::map<std::string, std::string> display;           // model name -> the specification's name
};
// Throws InputError when the specification is not valid GTSL or the log cannot be read; AccessDenied without a token.
GIOLIT_API ConformResult conformLog(const AccessToken& token, const std::string& specPath, const std::string& logPath, const SpecOptions& options);

// Optimization (Q4) over all behaviours: the best and the worst value the objective can take (at the session's close,
// or at any step), each as a value a run reaches and a proved bound, within `seconds` in all.
GIOLIT_API void optimizeObjective(const AccessToken& token, const std::string& path, const TradeOptions& options, TradeResult& result,
                                  double seconds = 60);

// Stars from the relative headroom: 5 from 50 %, 4 from 25 %, 3 from 10 %, 2 above 0, 1 when the limit is reached.
inline int resilienceStars(double relative) {
    if (relative < 0) return 0;
    return relative >= 0.5 ? 5 : relative >= 0.25 ? 4 : relative >= 0.1 ? 3 : relative > 0 ? 2 : 1;
}

}
