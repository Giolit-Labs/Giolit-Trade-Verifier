#pragma once
// Giolit Trading Risk Verifier -- public API, common part.
//
// The verifier ships as shared libraries. Each licensed library exports only
// the entry points declared under api/giolit/, and every one of them takes an
// AccessToken: a short-lived token signed by the license library
// (License.hpp), which issues it only while a trial or a purchased license is
// valid. Everything else in the libraries is hidden from the linker.
#include <stdexcept>
#include <string>

#define GIOLIT_API __attribute__((visibility("default")))

namespace giolit {

// A signed, short-lived access token (giolit::acquireToken).
struct AccessToken {
    std::string value;
};

// Thrown by a licensed entry point when the token is missing, forged or
// expired.
struct GIOLIT_API AccessDenied : std::runtime_error {
    using std::runtime_error::runtime_error;
};

// The input cannot be analysed (syntax error, unsupported construct, compiler
// error). line: where, when known (0 otherwise).
struct GIOLIT_API InputError : std::runtime_error {
    int line = 0;
    InputError(const std::string& message, int line_) : std::runtime_error(message), line(line_) {}
};

}
