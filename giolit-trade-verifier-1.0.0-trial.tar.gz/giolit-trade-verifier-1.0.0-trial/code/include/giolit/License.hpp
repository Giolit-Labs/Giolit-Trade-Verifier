#pragma once
// Giolit Trading Risk Verifier -- the license library (libgiolit_license).
//
// The only component that can issue access tokens. A token is issued while
// the installation's trial (1000 runs within 50 days, in a build at most 100
// days old) or an activated license is valid; each issued token counts as
// one run. The local license state is signed; editing or deleting it does not
// reset the trial.
#include "giolit/Api.hpp"
#include <string>

namespace giolit {

struct TokenGrant {
    bool granted = false;
    AccessToken token;          // granted: valid for this run
    std::string tier;           // granted: "trial" or "paid"
    long long runsRemaining = -1;  // granted: runs left (-1: unlimited)
    long long validUntil = 0;   // granted: the token's expiry (epoch seconds)
    std::string message;        // !granted: why, with how to get a license
};

// Checks the license state and, when valid, charges one run and issues a
// token for the licensed libraries.
GIOLIT_API TokenGrant acquireToken();

enum class ActivationOutcome { Applied, AlreadyApplied, InvalidSignature, Malformed, StateCorrupted, IdentityMismatch };
struct Activation {
    ActivationOutcome outcome = ActivationOutcome::Malformed;
    std::string message;
};

// The buyer a license was issued to, as entered at activation.
struct Licensee {
    std::string name, address, password;
};

// Whether a license file is bound to its buyer (activation then needs the
// buyer's name, address and password). False for unreadable files.
GIOLIT_API bool licenseNeedsBuyer(const std::string& licenseFile);

// Applies a purchased license file (issued by Giolit) to this installation.
// A license bound to its buyer applies only when `buyer` gives the name,
// address and password it was issued for (IdentityMismatch otherwise).
GIOLIT_API Activation activateLicense(const std::string& licenseFile, const Licensee* buyer = nullptr);

// Where this installation keeps its license state (GIOLIT_HOME, default
// ~/.giolit/trade-verify).
GIOLIT_API std::string licenseHome();

// The installation's license, read without charging a run (no token needed).
struct LicenseStatus {
    std::string kind;              // "trial", "licensed", "unlimited", "not started" (no run yet), "damaged"
    bool usable = false;           // a run would be allowed now
    std::string licenseId;         // licensed/unlimited: the applied license
    long long runsUsed = 0;
    long long runsAllowed = -1;    // -1: unlimited
    long long startedAt = 0;       // the first run (0: none yet)
    long long expiresAt = -1;      // end of the trial or license period (-1: none; for "not started": days * 86400)
    long long buildDate = 0;       // when this build was made
    long long buildExpiresAt = 0;  // after this, the build needs an active purchased license
    bool buildExpiryApplies = true;  // false while a purchased license is active
    std::string message;           // !usable: why
    // A purchased license is applied and in force: documents are issued
    // under it (professional), not as trial output.
    bool professional = false;
    std::string licensee, licenseeAddress;  // the buyer it was activated for (bound licenses)
};
GIOLIT_API LicenseStatus licenseStatus();

// --- Certificate signing --------------------------------------------------
// A licensee signs certificates with its own key. Giolit issues the key as a
// signing credential (licensee, license ID, public key, expiry), signed with
// Giolit's master key; activateLicense() applies a credential file like a
// license file. The chain a client checks: Giolit's published master key ->
// the credential -> the certificate.
struct StatementSignature {
    bool signedByLicensee = false;    // false: no valid credential (e.g. a trial); nothing signed
    std::string licensee, licenseId;
    std::string publicKeyHex;         // the licensee's signing key (Ed25519, hex)
    std::string credential;           // the credential payload, exactly as Giolit signed it (JSON text)
    std::string credentialSignature;  // Giolit's signature of `credential` (base64url)
    std::string signature;            // the licensee's signature of the statement bytes (base64url)
    long long credentialExpires = 0;  // epoch seconds; 0: no expiry
    std::string message;              // !signedByLicensee: why
};

// Signs `statement` (the exact bytes of a certificate statement) with the
// activated signing credential. Throws AccessDenied without a valid token.
GIOLIT_API StatementSignature signStatement(const AccessToken& token, const std::string& statement);

// Giolit's master public key (Ed25519, hex): the root of every certificate
// chain. Clients should compare its fingerprint with the one on www.giolit.com.
GIOLIT_API std::string masterPublicKeyHex();

}
