#pragma once
// The engines (libgiolit_backend): the prover (CEGAR over slot vectors), the inductive-lemma prover, the explicit-state
// explorer and the random simulator, raced against each other on one model.
#include "giolit/Api.hpp"
#include "vtask/Result.hpp"
#include "vtask/Task.hpp"

namespace giolit {

enum Engine : unsigned { Prover = 1, Explorer = 2, Simulator = 4, Lemmas = 8, AllEngines = 15 };

struct VerifyOptions {
    double seconds = 60;
    unsigned engines = AllEngines;
    bool needInvariants = false;   // a proof must come with invariants (a certificate): no proof by enumeration
    bool certificates = false;     // keep the proofs' invariants for a report (the enumerated states, too)
    uint64_t seed = 0;             // the simulator's random choices (0: the fixed default); a rerun with another seed searches elsewhere
};

struct Verification {
    vtask::Task task;
    vtask::Result result;   // one CheckResult per Task::checks entry
    double seconds = 0;
};

// Throws AccessDenied without a valid token.
GIOLIT_API Verification verifyDesign(const AccessToken& token, const vtask::Task& task, const VerifyOptions& options);

// A shorter run to the same violation of check `checkId`: whole steps of the model's step boundary
// (Region::CycleStart) deleted while the rest still replays and still violates it. Throws AccessDenied without a valid
// token.
GIOLIT_API vtask::Counterexample shortenCounterexample(const AccessToken& token, const vtask::Task& task, const vtask::Counterexample& cex,
                                                       int checkId, double seconds);
}
