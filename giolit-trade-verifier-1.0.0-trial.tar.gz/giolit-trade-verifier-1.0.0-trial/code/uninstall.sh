#!/usr/bin/env bash
# uninstall.sh: removes this installation of the Giolit Trading Risk Verifier (the license state is kept).
set -euo pipefail
prefix="$(cd "$(dirname "$0")" && pwd)"
[ -x "$prefix/bin/trade-verify" ] || { echo "uninstall.sh: $prefix is not a Giolit installation" >&2; exit 1; }
if [ -f "$prefix/.bindir" ]; then
    bindir="$(cat "$prefix/.bindir")"
    [ "$(readlink "$bindir/trade-verify" 2>/dev/null)" = "$prefix/bin/trade-verify" ] && rm -f "$bindir/trade-verify"
fi
rm -rf "${prefix:?}/bin" "$prefix/lib" "$prefix/include" "$prefix/share" "$prefix/.bindir"
rm -f "$prefix/uninstall.sh"
rmdir "$prefix" 2>/dev/null || true
echo "Removed $prefix. Your license state (~/.giolit/trade-verify) was kept."
