#!/usr/bin/env bash
# install.sh [--system | --prefix DIR]: installs the Giolit Trading Risk Verifier.
#
#   (no option)    into ~/.local/giolit-trade-verifier, with the command in ~/.local/bin
#   --system       into /opt/giolit-trade-verifier, with the command in /usr/local/bin (run with sudo)
#   --prefix DIR   into DIR, without a command link
#
# The installer checks the system libraries, copies the programs, libraries, headers, examples and templates, and
# runs a short self-test (one verification: one run of your trial or license).
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
prefix="$HOME/.local/giolit-trade-verifier"
bindir="$HOME/.local/bin"
case "${1:-}" in
    --system) prefix=/opt/giolit-trade-verifier; bindir=/usr/local/bin ;;
    --prefix) [ -n "${2:-}" ] || { echo "install.sh: --prefix needs a folder" >&2; exit 2; }
              prefix="$(mkdir -p "$2" && cd "$2" && pwd)"; bindir="" ;;
    "") ;;
    -h|--help) sed -n '2,9p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "install.sh: unknown option $1 (see --help)" >&2; exit 2 ;;
esac

say() { printf '  %s\n' "$*"; }
echo "Giolit Trading Risk Verifier -- installing into $prefix"
echo "By installing or using the software you accept its License Terms"
echo "(documents/License-Terms.pdf in this package)."

missing=$(LD_LIBRARY_PATH="$here/lib" ldd "$here/bin/trade-verify" "$here"/lib/*.so 2>/dev/null | awk '/not found/ {print $1}' | sort -u)
if [ -n "$missing" ]; then
    echo
    echo "The verifier needs these system libraries, which are not installed:"
    for m in $missing; do say "$m"; done
    echo
    echo "On Ubuntu 24.04 install them with:"
    say "sudo apt install libllvm18 libclang-cpp18 libclang-common-18-dev libc6-dev libssl3"
    echo "then run install.sh again."
    exit 1
fi

mkdir -p "$prefix"
for d in bin lib include share; do
    rm -rf "${prefix:?}/$d"
    cp -a "$here/$d" "$prefix/$d"
done
cp -a "$here/uninstall.sh" "$prefix/uninstall.sh"
say "program    $prefix/bin/trade-verify"
say "libraries  $prefix/lib (the SDK: see the SDK guide)"
say "headers    $prefix/include/giolit"
say "examples   $prefix/share/giolit/examples, templates, sdk-examples"

if [ -n "$bindir" ]; then
    mkdir -p "$bindir"
    ln -sf "$prefix/bin/trade-verify" "$bindir/trade-verify"
    printf '%s\n' "$bindir" > "$prefix/.bindir"
    say "command    $bindir/trade-verify"
    case ":$PATH:" in
        *":$bindir:"*) ;;
        *) echo; echo "Add $bindir to your PATH, e.g.:  echo 'export PATH=\"$bindir:\$PATH\"' >> ~/.bashrc" ;;
    esac
fi

echo
if ! command -v lualatex >/dev/null 2>&1; then
    echo "Note: lualatex is not installed; the verifier works fully, but --report writes no PDF. For PDFs:"
    say "sudo apt install texlive-luatex texlive-latex-recommended texlive-latex-extra texlive-pictures texlive-fonts-extra qpdf"
fi
command -v python3 >/dev/null 2>&1 || echo "Note: python3 is not installed; importing strategies written in Python needs it."
command -v java >/dev/null 2>&1 || echo "Note: java is not installed; importing strategies written in Java needs a JDK (sudo apt install default-jdk)."

echo
"$prefix/bin/trade-verify" --version
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
cp "$prefix/share/giolit/examples/02_position_limit_fixed.gts" "$tmp/"
if (cd "$tmp" && "$prefix/bin/trade-verify" --timeout=30 02_position_limit_fixed.gts > "$tmp/out.txt" 2>&1); then
    echo "Self-test: 02_position_limit_fixed.gts -- $(grep -o 'ALL CONSTRAINTS PROVEN' "$tmp/out.txt" | head -1)"
else
    rc=$?
    echo "Self-test did not pass (exit code $rc):"
    sed 's/^/    /' "$tmp/out.txt" | tail -15
    [ $rc -eq 4 ] && echo "Exit code 4 is a license problem; run: trade-verify --license"
    exit 1
fi
echo
echo "Installed. Next steps:"
say "trade-verify --help                                    all options"
say "trade-verify --license                                 your trial: runs and days left"
say "cd $prefix/share/giolit/examples && trade-verify 01_position_limit.gts      a violation, as a run"
say "trade-verify --templates                               the strategy pattern library"
