// The VWAP with its schedule fixed: the rule also runs at `end`, where the target is the whole quantity, so the
// execution can complete (the target `completes` is FEASIBLE: the tool shows a run that does).
spec VwapExecutionFixed;

units { time = 1s; price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; volume_step 0 .. 5000; }

assumptions {
    session 09:15 .. 15:30;
    market.bid <= market.ask;
}

market symbolic { symbol INFY; }

strategy VWAP {
    parameters {
        quantity = 10000;
        start = 09:30;
        end = 15:00;
        max_participation = 10%;
        child_max = 500;
    }
    rules {
        on clock when time in [start, end] {
            let target = quantity * (time - start) / (end - start);
            let gap = target - bought - open_qty(buy);
            if gap > 0 and participation < max_participation {
                buy(min(child_max, gap), limit = market.bid);
            }
        }
        on session_close {
            cancel_all();
        }
    }
}

risk_controls {
    clip:     reject when order.qty > child_max;
    schedule: reject when bought + open_qty(buy) + order.qty > quantity;
}

constraints {
    never_over:   always bought <= quantity;
    child_size:   always on new_order: order.qty <= child_max;
    on_schedule:  always bought + open_qty(buy) <= quantity;
    no_selling:   always sold == 0;
    completes:    feasible at end: bought == quantity;
    flat_at_end:  at end: open_qty(buy) == 0 or bought <= quantity;
}
