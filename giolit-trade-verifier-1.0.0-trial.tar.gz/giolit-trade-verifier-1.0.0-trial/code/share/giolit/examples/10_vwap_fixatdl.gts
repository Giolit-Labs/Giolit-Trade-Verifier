// The fixed VWAP of 09_vwap_fixed.gts with its parameters as an OMS offers them to clients: every start and end time,
// participation rate and child size the FIXatdl definition allows (the verification covers all of them at once),
// on a venue whose FIX Orchestra state machine cancels expiring orders and may fill an order after cancelling it.
// Found: the venue expires an order, the strategy re-sends what was left, and a late fill of the expired order
// arrives -- the algo over-executes (on_schedule VIOLATED). child_size is PROVEN for every client child size.
spec VwapClientParameters;

units { time = 1s; price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; volume_step 0 .. 5000; }

assumptions {
    session 09:15 .. 15:30;
    market.bid <= market.ask;
    start < end;
}

protocol from orchestra "imports/venue.orchestra.xml";

market symbolic { symbol INFY; }

strategy VWAP {
    parameters { quantity = 1000; }
    parameters from fixatdl "imports/algos.fixatdl.xml" strategy "VWAP" {
        start = StartTime;
        end = EndTime;
        max_participation = ParticipationRate;
        child_max = MaxChildQty;
    }
    rules {
        on clock when time in [start, end] {
            let target = quantity * (time - start) / (end - start);
            let gap = target - bought - open_qty(buy);
            if gap > 0 and participation < max_participation {
                buy(min(child_max, gap), limit = market.bid);
            }
        }
        on session_close {
            cancel_all();
        }
    }
}

risk_controls {
    clip:     reject when order.qty > child_max;
    schedule: reject when bought + open_qty(buy) + order.qty > quantity;
}

constraints {
    never_over:   always bought <= quantity;
    child_size:   always on new_order: order.qty <= child_max;
    on_schedule:  always bought + open_qty(buy) <= quantity;
}
