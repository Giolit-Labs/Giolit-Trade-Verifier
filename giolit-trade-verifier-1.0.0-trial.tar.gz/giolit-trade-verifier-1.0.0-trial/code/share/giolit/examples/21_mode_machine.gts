// A strategy driven by a mode (idle, entering, holding, exiting): the position and the working orders follow the mode,
// an invariant per mode. The provers get it through the one-hot encoding of `mode` (DESIGN section 18).
spec ModeMachine;
units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 100; }
strategy Modes {
    parameters { q = 100; }
    state { mode: int = 0; }   // 0 idle, 1 entering (a buy working), 2 holding, 3 exiting (a sell working)
    rules {
        on market_update when mode == 0 { buy(q, limit = market.bid); mode = 1; }
        on fill when mode == 1 and order.leaves == 0 { mode = 2; }
        on market_update when mode == 2 { sell(q, limit = market.ask); mode = 3; }
        on fill when mode == 3 and order.leaves == 0 { mode = 0; }
        on reject when mode == 1 { mode = 0; }
        on reject when mode == 3 { mode = 2; }
    }
}
constraints {
    long_only: always position >= 0;
    capped:    always position <= q;
    one_order: always open_orders <= 1;
}
