// certify SPEC.gts OUT_DIR [ISSUED_TO]: verify with proofs and headroom, then write the evidence bundle.
#include "common.hpp"
#include "giolit/Report.hpp"
#include "giolit/Trade.hpp"

int main(int argc, char** argv) {
    if (argc < 3) { std::cerr << "usage: certify SPEC.gts OUT_DIR [ISSUED_TO]\n"; return 3; }
    giolit::AccessToken tok = tokenOrExit();
    giolit::TradeOptions o;
    o.seconds = 60;
    o.certificates = true;   // keep the proofs: the certificate shows them
    giolit::TradeResult r = giolit::verifySpec(tok, argv[1], o);
    giolit::addHeadroom(tok, argv[1], o, r, 60);
    for (auto& c : r.constraints) {
        giolit::TradeProof p = giolit::describeProof(tok, c, r.facts);
        std::cout << c.name << ": " << giolit::toString(c.verdict) << "\n";
        for (auto& rel : p.relations) std::cout << "    " << rel << "\n";
    }
    giolit::ReportRequest rq;
    rq.specFile = argv[1];
    rq.outDir = argv[2];
    rq.issuedTo = argc > 3 ? argv[3] : "";
    rq.commandLine = {"certify", argv[1], argv[2]};
    rq.engineVersion = "1.0.0";
    rq.engineBuild = "sdk";
    giolit::ReportOutcome ro = giolit::writeReport(tok, r, rq);
    std::cout << "bundle " << argv[2] << ": " << giolit::toString(ro.verdict) << ", document " << ro.documentId
              << (ro.pdfOk ? ", " + ro.pdfPath : ", no PDF: " + ro.message) << "\n";
}
