// verify_spec SPEC.gts [SECONDS]: every constraint's verdict, how it was decided, and the violating runs.
#include "common.hpp"
#include "giolit/Trade.hpp"

int main(int argc, char** argv) {
    if (argc < 2) { std::cerr << "usage: verify_spec SPEC.gts [SECONDS]\n"; return 3; }
    giolit::AccessToken tok = tokenOrExit();
    giolit::TradeOptions o;
    o.seconds = argc > 2 ? std::atof(argv[2]) : 60;
    try {
        giolit::TradeResult r = giolit::verifySpec(tok, argv[1], o);
        std::cout << "spec " << r.spec << " (" << r.seconds << " s)\n";
        for (const giolit::ConstraintResult& c : r.constraints) {
            std::cout << "  " << giolit::toString(c.verdict) << "  " << c.name << ": " << c.text << "\n      " << c.method << "\n";
            for (size_t i = 0; i < c.trace.size(); ++i) {
                const giolit::TraceStep& s = c.trace[i];
                std::cout << "      " << i << "  " << s.event;
                for (auto& a : s.actions) std::cout << "  -> " << a;
                auto pos = s.state.find("position");
                if (pos != s.state.end()) std::cout << "   position=" << pos->second;
                std::cout << "\n";
            }
        }
        for (const giolit::ConstraintResult& c : r.sanity)
            if (c.verdict == giolit::Verdict::Infeasible) std::cout << "  warning: " << c.text << ": never\n";
    } catch (const giolit::InputError& e) {
        std::cerr << argv[1] << ":" << e.line << ": " << e.what() << "\n";
        return 3;
    }
}
