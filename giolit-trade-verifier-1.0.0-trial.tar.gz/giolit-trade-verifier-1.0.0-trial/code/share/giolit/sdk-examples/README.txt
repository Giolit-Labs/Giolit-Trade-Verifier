Giolit Trading Risk Verifier -- SDK examples

  verify_spec SPEC.gts [SECONDS]     verdicts, methods and violating runs          (giolit::verifySpec)
  headroom SPEC.gts                   worst values of the proven limits, stars      (giolit::addHeadroom)
  conform SPEC.gts LOG.fix            conformance replay of a FIX log              (giolit::conformLog)
  certify SPEC.gts DIR [ISSUED_TO]    proofs in the specification's terms, bundle  (describeProof, writeReport)

Build: ./build.sh [INSTALL_DIR]   (default ~/.local/giolit-trade-verifier)
Every call needs a token from giolit::acquireToken() (common.hpp); each run counts against the license like a run of
trade-verify. Headers: include/giolit/*.hpp; the result types are documented in Trade.hpp and Report.hpp.
