#pragma once
// Shared by the SDK examples: a license token, or a clear message and exit code 4.
#include "giolit/License.hpp"
#include <cstdlib>
#include <iostream>

inline giolit::AccessToken tokenOrExit() {
    giolit::TokenGrant g = giolit::acquireToken();
    if (!g.granted) {
        std::cerr << g.message << "\n";
        std::exit(4);
    }
    return g.token;
}
