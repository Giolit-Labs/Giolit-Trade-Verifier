// conform SPEC.gts LOG.fix: replay a FIX log through the specification; exit 1 when it does not conform.
#include "common.hpp"
#include "giolit/Trade.hpp"

int main(int argc, char** argv) {
    if (argc < 3) { std::cerr << "usage: conform SPEC.gts LOG.fix\n"; return 3; }
    giolit::AccessToken tok = tokenOrExit();
    giolit::ConformResult c = giolit::conformLog(tok, argv[1], argv[2], giolit::SpecOptions{});
    int serious = 0;
    for (auto& i : c.issues) {
        if (i.kind == giolit::ConformIssue::Kind::Note) continue;
        ++serious;
        std::cout << giolit::toString(i.kind) << " at message " << i.message << ": " << i.why << "\n";
    }
    std::cout << c.replayed << " of " << c.messages << " messages replayed, " << serious << " deviation(s)\n";
    return serious ? 1 : 0;
}
