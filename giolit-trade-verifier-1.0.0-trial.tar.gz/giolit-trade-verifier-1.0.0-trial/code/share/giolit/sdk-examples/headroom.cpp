// headroom SPEC.gts: for every proven limit, the worst value any run reaches and the resilience score.
#include "common.hpp"
#include "giolit/Trade.hpp"

int main(int argc, char** argv) {
    if (argc < 2) { std::cerr << "usage: headroom SPEC.gts\n"; return 3; }
    giolit::AccessToken tok = tokenOrExit();
    giolit::TradeOptions o;
    o.seconds = 30;
    giolit::TradeResult r = giolit::verifySpec(tok, argv[1], o);
    giolit::addHeadroom(tok, argv[1], o, r, 60);
    for (auto& c : r.constraints) {
        if (!c.hasHeadroom) continue;
        std::cout << c.name << ": " << c.bounded << (c.upper ? " <= " : " >= ") << c.worst << " on every run (limit " << c.limitText << " = "
                  << c.limit << ")" << (c.worstExact ? ", reached by a run" : "") << "; " << c.stars << " star(s)\n";
    }
    std::cout << "Giolit Risk Resilience Score: " << r.resilienceStars << " of 5\n";
}
