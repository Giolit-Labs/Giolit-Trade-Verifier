// TEMPLATE twap -- a parent buy order worked evenly over time (time-weighted)
//
// Adapt: quantity, start, end and child_max; the limit (here: join the bid); the session.
// The schedule: bought + open = quantity * (time - start) / (end - start), in children of at most child_max.
//
// Standard constraints of the family:
//   never_over    the parent is never overfilled (fills of orders still working included)
//   on_schedule   bought + open never runs ahead of the parent quantity
//   child_size    every child order is at most child_max
//   one_side      a buy algorithm never sells
//   completes     a run exists that completes the parent by the close (FEASIBLE; a long horizon: the witness has about
//                 700 events and needs --timeout=300 or so; within 60 s it may stay UNDECIDED)
spec TwapTemplate;

units { time = 1s; price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; volume_step 0 .. 5000; }
assumptions {
    session 09:15 .. 15:30;
    market.bid <= market.ask;
}

strategy TWAP {
    parameters {
        quantity = 10000;
        start = 09:30;
        end = 15:00;
        child_max = 500;
    }
    rules {
        on clock when time in [start, end] {
            let target = quantity * (time - start) / (end - start);
            let gap = target - bought - open_qty(buy);
            if gap > 0 { buy(min(child_max, gap), limit = market.bid); }
        }
        on session_close { cancel_all(); }
    }
}

risk_controls {
    clip:     reject when order.qty > child_max;
    schedule: reject when bought + open_qty(buy) + order.qty > quantity;
}

constraints {
    never_over:  always bought <= quantity;
    on_schedule: always bought + open_qty(buy) <= quantity;
    child_size:  always on new_order: order.qty <= child_max;
    one_side:    always sold == 0;
    completes:   feasible at end: bought == quantity;
}
