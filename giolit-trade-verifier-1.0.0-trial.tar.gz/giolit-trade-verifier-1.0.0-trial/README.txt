GIOLIT TRADING RISK VERIFIER 1.0 -- TRIAL EDITION
=================================================

Formal verification of trading strategies and risk controls: a proof that every
rule holds on every run -- any market move, fill, reject, cancel and message
order your assumptions allow, for any number of orders -- or the event-by-event
run (also as FIX 4.4 messages) that breaks one.

  code/        the verifier: the trade-verify command, its libraries (the SDK), the
               public C++ headers, examples, strategy templates, SDK examples, and
               install.sh
  documents/   Brochure.pdf (the product in four pages), Tutorial-1 (verifying
               strategies: start here), Tutorial-2 (the SDK), Tutorial-3 (algorithmic
               trading and how we verify it), Reference-Manual.pdf (the language and
               every option), README.pdf, License-Terms.pdf, and the same documents as
               Markdown, with the SDK guide's example programs and THIRD-PARTY-NOTICES
  benchmarks/  every specification with a known answer: the tutorial examples, the
               strategy templates, strategies imported from C++, Python and Java, and
               open-source strategies verified from their unmodified code (with their
               licenses); MANIFEST.tsv lists every constraint and its expected verdict
  results/     the verifier's result for every benchmark, in the same folders:
               console output, results.json, reproduce.sh (SUMMARY.csv lists them)
  SHA256SUMS   checksums of every file (sha256sum -c SHA256SUMS)

Quick start (Ubuntu 24.04):

  sudo apt install libllvm18 libclang-cpp18 libclang-common-18-dev libc6-dev libssl3
  cd code && ./install.sh
  cd ~/.local/giolit-trade-verifier/share/giolit/examples
  trade-verify 02_position_limit_fixed.gts     ALL CONSTRAINTS PROVEN
  trade-verify 01_position_limit.gts           CONSTRAINT VIOLATIONS FOUND (with the run)

PDF certificates need LuaLaTeX and qpdf:
  sudo apt install texlive-luatex texlive-latex-recommended texlive-latex-extra \
                   texlive-pictures texlive-fonts-extra qpdf
Importing strategies needs python3 (Python) or a JDK (Java).

The trial allows 1000 runs within 50 days. Licenses, verification services
and training: www.giolit.com -- business.giolitlabs@gmail.com

Giolit Labs -- Ramavarmapuram P.O., Thrissur, Kerala, India
