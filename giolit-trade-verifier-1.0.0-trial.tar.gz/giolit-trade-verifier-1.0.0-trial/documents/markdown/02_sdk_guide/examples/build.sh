#!/bin/sh
# build.sh [INSTALL_DIR]: builds the SDK guide's examples against an installed trade-verify
# (default ~/.local/giolit-trade-verifier).
set -e
prefix="${1:-$HOME/.local/giolit-trade-verifier}"
here="$(cd "$(dirname "$0")" && pwd)"
for p in release_gate limit_sweep explain_run; do
    c++ -std=c++17 -O1 -I"$prefix/include" "$here/$p.cpp" -o "$here/$p" -L"$prefix/lib" -Wl,-rpath,"$prefix/lib" \
        -lgiolit_trade -lgiolit_report -lgiolit_frontend -lgiolit_backend -lgiolit_license -lgiolit_interface
    echo "built $here/$p"
done
