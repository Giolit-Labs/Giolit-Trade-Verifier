// limit_sweep SPEC.gts PARAMETER CONSTRAINT LOW HIGH: the largest value of a strategy parameter (for example the clip
// size) for which a constraint is still PROVEN, by bisection over the parameter.
//
// Each probe overrides the parameter (like `trade-verify -P NAME=VALUE`) and verifies only the one constraint (its cone
// of influence, like `--constraint=NAME`), so a probe takes seconds. A probe that ends VIOLATED shows the run that
// breaks the constraint at that value.
#include "giolit/License.hpp"
#include "giolit/Trade.hpp"
#include <cstdlib>
#include <iostream>
#include <string>

namespace {
giolit::Verdict probe(const giolit::AccessToken& tok, const char* spec, const std::string& param, long long value, const std::string& constraint) {
    giolit::TradeOptions o;
    o.seconds = 30;
    o.lower.parameters[param] = std::to_string(value);
    o.lower.only = constraint;
    o.lower.sanity = false;   // the sanity checks were seen in the full run; probes need only the verdict
    giolit::TradeResult r = giolit::verifySpec(tok, spec, o);
    for (const giolit::ConstraintResult& c : r.constraints)
        if (c.name == constraint) return c.verdict;
    return giolit::Verdict::Undecided;
}
}

int main(int argc, char** argv) {
    if (argc != 6) {
        std::cerr << "usage: limit_sweep SPEC.gts PARAMETER CONSTRAINT LOW HIGH\n";
        return 3;
    }
    giolit::TokenGrant g = giolit::acquireToken();
    if (!g.granted) {
        std::cerr << g.message << "\n";
        return 4;
    }
    const char* spec = argv[1];
    const std::string param = argv[2], constraint = argv[3];
    long long lo = std::atoll(argv[4]), hi = std::atoll(argv[5]);
    try {
        if (probe(g.token, spec, param, lo, constraint) != giolit::Verdict::Proven) {
            std::cout << constraint << " is not proven even with " << param << " = " << lo << "\n";
            return 1;
        }
        // invariant: proven at lo; not known (or not proven) above hi
        while (lo < hi) {
            const long long mid = lo + (hi - lo + 1) / 2;
            const giolit::Verdict v = probe(g.token, spec, param, mid, constraint);
            std::cout << "  " << param << " = " << mid << ": " << giolit::toString(v) << "\n";
            if (v == giolit::Verdict::Proven) lo = mid;
            else hi = mid - 1;   // violated, or not proven within the budget: treated as unsafe
        }
    } catch (const giolit::InputError& e) {
        std::cerr << spec << ":" << e.line << ": " << e.what() << "\n";
        return 3;
    }
    std::cout << "largest " << param << " with " << constraint << " PROVEN: " << lo << "\n";
}
