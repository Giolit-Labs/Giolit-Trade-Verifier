// explain_run SPEC.gts CONSTRAINT: verify one constraint and, when it is violated, print the run with the full state
// and the order book after every event -- what an engineer needs to reproduce the failure in a back-test.
#include "giolit/License.hpp"
#include "giolit/Trade.hpp"
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "usage: explain_run SPEC.gts CONSTRAINT\n";
        return 3;
    }
    giolit::TokenGrant g = giolit::acquireToken();
    if (!g.granted) {
        std::cerr << g.message << "\n";
        return 4;
    }
    giolit::TradeOptions o;
    o.seconds = 60;
    o.lower.only = argv[2];
    o.lower.traceState = true;   // every displayed variable in the run, not only those the constraint needs
    giolit::TradeResult r;
    try {
        r = giolit::verifySpec(g.token, argv[1], o);
    } catch (const giolit::InputError& e) {
        std::cerr << argv[1] << ":" << e.line << ": " << e.what() << "\n";
        return 3;
    }
    for (const giolit::ConstraintResult& c : r.constraints) {
        std::cout << c.name << ": " << giolit::toString(c.verdict) << " (" << c.method << ")\n";
        if (c.verdict != giolit::Verdict::Violated) continue;
        for (size_t k = 0; k < c.trace.size(); ++k) {
            const giolit::TraceStep& s = c.trace[k];
            std::cout << "\n" << k << "  " << (k == 0 ? "initial state" : s.event) << "\n";
            for (const std::string& a : s.actions) std::cout << "   -> " << a << "\n";
            for (const auto& [name, value] : s.state) std::cout << "   " << name << " = " << value << "\n";
            for (const auto& [name, value] : s.reals) std::cout << "   " << name << " = " << value << "\n";
            for (const giolit::TraceOrder& ord : s.orders)
                std::cout << "   order O" << ord.id << " " << ord.side << " " << ord.qty << (ord.price >= 0 ? " @ " + std::to_string(ord.price) : " MKT")
                          << " filled " << ord.cum << " " << ord.state << (ord.venue.empty() ? "" : " at " + ord.venue) << "\n";
        }
        std::cout << "\nprices are in ticks of " << (r.facts.count("#tick") ? r.facts.at("#tick") : std::string("?")) << " "
                  << (r.facts.count("#currency") ? r.facts.at("#currency") : std::string()) << "\n";
    }
    return 0;
}
