// release_gate SPEC.gts [SPEC.gts ...]: verify every specification and decide whether a release may go out.
//
// The gate fails (exit 1) when any constraint is VIOLATED and prints the run that breaks it; it reports constraints that
// stayed UNDECIDED (exit 2 when nothing is violated), and passes (exit 0) when every constraint of every specification
// is PROVEN. A specification that is not valid GTSL is an input error (exit 3).
#include "giolit/License.hpp"
#include "giolit/Trade.hpp"
#include <cstdlib>
#include <iostream>

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cerr << "usage: release_gate SPEC.gts [SPEC.gts ...]\n";
        return 3;
    }
    giolit::TokenGrant grant = giolit::acquireToken();
    if (!grant.granted) {
        std::cerr << grant.message << "\n";
        return 4;
    }
    int violated = 0, open = 0;
    for (int i = 1; i < argc; ++i) {
        giolit::TradeOptions options;
        options.seconds = 120;   // the whole budget of one specification
        giolit::TradeResult r;
        try {
            r = giolit::verifySpec(grant.token, argv[i], options);
        } catch (const giolit::InputError& e) {
            std::cerr << argv[i] << ":" << e.line << ": " << e.what() << "\n";
            return 3;
        }
        std::cout << "== " << r.spec << " (" << argv[i] << ", " << r.seconds << " s)\n";
        for (const giolit::ConstraintResult& c : r.constraints) {
            std::cout << "  " << giolit::toString(c.verdict) << "  " << c.name << "\n";
            if (c.verdict == giolit::Verdict::Violated) {
                ++violated;
                for (size_t k = 1; k < c.trace.size(); ++k) {   // trace[0] is the initial state
                    std::cout << "      " << k << "  " << c.trace[k].event << "\n";
                    for (const std::string& a : c.trace[k].actions) std::cout << "           -> " << a << "\n";
                }
            } else if (c.verdict == giolit::Verdict::Undecided || c.verdict == giolit::Verdict::ProvenBounded) {
                ++open;
                if (!c.cause.empty()) std::cout << "      " << c.cause << "\n";
            }
        }
        // a sanity check that fails means a constraint may hold only vacuously: worth a look before a release
        for (const giolit::ConstraintResult& s : r.sanity)
            if (s.verdict == giolit::Verdict::Infeasible) std::cout << "  warning: " << s.text << ": never\n";
    }
    std::cout << (violated ? "GATE FAILED" : open ? "GATE OPEN (undecided constraints)" : "GATE PASSED") << ": " << violated
              << " violated, " << open << " undecided\n";
    return violated ? 1 : open ? 2 : 0;
}
