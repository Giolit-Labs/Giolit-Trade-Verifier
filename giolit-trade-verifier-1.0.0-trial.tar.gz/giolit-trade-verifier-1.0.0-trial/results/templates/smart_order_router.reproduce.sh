#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/templates" && trade-verify smart_order_router.gts --timeout=30
