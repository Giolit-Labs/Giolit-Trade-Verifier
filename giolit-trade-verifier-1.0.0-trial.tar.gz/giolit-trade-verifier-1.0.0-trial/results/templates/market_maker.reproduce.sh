#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/templates" && trade-verify market_maker.gts --timeout=30
