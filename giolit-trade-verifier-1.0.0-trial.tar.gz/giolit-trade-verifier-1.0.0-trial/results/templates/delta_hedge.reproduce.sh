#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/templates" && trade-verify delta_hedge.gts --timeout=30
