#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/templates" && trade-verify vwap.gts --timeout=30
