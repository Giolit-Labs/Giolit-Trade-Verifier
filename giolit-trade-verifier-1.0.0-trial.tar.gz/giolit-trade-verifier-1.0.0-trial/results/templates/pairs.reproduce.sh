#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/templates" && trade-verify pairs.gts --timeout=60
