#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../../benchmarks/imports/cpp_clip" && trade-verify clip_fixed.gts --timeout=60
