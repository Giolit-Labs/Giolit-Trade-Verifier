#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../../benchmarks/imports/real_wondertrader_vwap" && trade-verify vwap.gts --timeout=120
