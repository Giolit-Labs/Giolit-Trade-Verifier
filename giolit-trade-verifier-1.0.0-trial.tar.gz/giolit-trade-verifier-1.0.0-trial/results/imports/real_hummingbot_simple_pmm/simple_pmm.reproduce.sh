#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../../benchmarks/imports/real_hummingbot_simple_pmm" && trade-verify simple_pmm.gts --timeout=30
