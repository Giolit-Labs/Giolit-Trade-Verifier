#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../../benchmarks/imports/cpp_mm" && trade-verify mm.gts --timeout=60
