#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../../benchmarks/imports/real_wondertrader_twap" && trade-verify twap.gts --timeout=180
