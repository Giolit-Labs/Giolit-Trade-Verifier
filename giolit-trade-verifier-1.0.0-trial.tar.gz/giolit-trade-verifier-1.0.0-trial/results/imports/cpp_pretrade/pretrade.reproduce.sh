#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../../benchmarks/imports/cpp_pretrade" && trade-verify pretrade.gts --timeout=60
