#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../../benchmarks/imports/py_clip" && trade-verify clip.gts --timeout=30
