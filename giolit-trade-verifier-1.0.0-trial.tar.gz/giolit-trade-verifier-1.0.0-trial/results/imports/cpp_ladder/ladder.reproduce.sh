#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../../benchmarks/imports/cpp_ladder" && trade-verify ladder.gts --timeout=30
