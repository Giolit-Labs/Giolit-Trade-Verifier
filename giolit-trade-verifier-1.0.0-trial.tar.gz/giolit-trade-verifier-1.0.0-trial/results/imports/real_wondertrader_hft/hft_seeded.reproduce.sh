#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../../benchmarks/imports/real_wondertrader_hft" && trade-verify hft_seeded.gts --timeout=180
