#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../../benchmarks/imports/real_wondertrader_dualthrust" && trade-verify dualthrust_seeded.gts --timeout=30
