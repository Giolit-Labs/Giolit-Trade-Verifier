#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/examples" && trade-verify 12_avellaneda_stoikov.gts --timeout=30
