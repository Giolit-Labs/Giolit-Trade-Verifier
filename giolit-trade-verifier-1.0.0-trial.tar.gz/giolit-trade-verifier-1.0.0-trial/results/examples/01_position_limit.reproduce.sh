#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/examples" && trade-verify 01_position_limit.gts --timeout=30
