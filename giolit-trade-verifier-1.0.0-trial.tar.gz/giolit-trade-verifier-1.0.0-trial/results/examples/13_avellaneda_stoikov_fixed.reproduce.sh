#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/examples" && trade-verify 13_avellaneda_stoikov_fixed.gts --timeout=30
