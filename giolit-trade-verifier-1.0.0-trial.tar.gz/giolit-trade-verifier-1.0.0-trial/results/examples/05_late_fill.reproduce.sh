#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/examples" && trade-verify 05_late_fill.gts --timeout=30
