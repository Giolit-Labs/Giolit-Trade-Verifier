#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/examples" && trade-verify 14_smart_order_router.gts --timeout=30
