#!/bin/sh
# reproduces this result with the installed verifier
cd "$(dirname "$0")/../../benchmarks/examples" && trade-verify 03_kill_switch.gts --timeout=30
