// WonderTrader's HFT demo strategy, verified from its C++ source.
spec WonderTraderHftDemo;

units { price = tick(0.2 INR); money = paise; }
ranges { price 15000 .. 25000; order_qty 1 .. 100; }
protocol fix44.limit_orders { fill_reports; }   // trade and order-status reports are separate messages (CTP: OnRtnTrade, OnRtnOrder)
signals {
    bid_qty: int in [1, 1000];
    ask_qty: int in [1, 1000];
    tick_time: int in [0, 235959999];
}
assumptions { market.bid < market.ask; }

import "hft.gbind";

constraints {
    one_working:  always open_orders <= 1;
    position_cap: always position <= 1 and position >= -1;
    tracked_sends: always on new_order: order.qty == 1;
}
