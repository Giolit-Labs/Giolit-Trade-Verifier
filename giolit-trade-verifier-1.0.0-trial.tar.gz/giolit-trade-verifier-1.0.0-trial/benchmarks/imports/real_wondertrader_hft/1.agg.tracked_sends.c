typedef long long i64;
extern i64 __VERIFIER_nondet_long(void);
extern _Bool __VERIFIER_nondet_bool(void);
extern void __VERIFIER_assume(int);
extern void __VERIFIER_assume_implied(i64, i64);
extern void __VERIFIER_assert(int);
extern i64 tv_fp(i64 op, i64 a, i64 b);   /* binary64 operator on bit patterns (not lowered) */
static inline __attribute__((always_inline)) i64 tv_nd(i64 lo, i64 hi) { i64 v = __VERIFIER_nondet_long(); __VERIFIER_assume(lo <= v && v <= hi); return v; }
static i64 g_time = 0LL;
static i64 g_bid = 0LL;
static i64 g_ask = 0LL;
static i64 g_last = 0LL;
static i64 g_vol = 0LL;
static i64 g_pos = 0LL;
static i64 g_bought = 0LL;
static i64 g_sold = 0LL;
static i64 g_cash = 0LL;
static i64 g_oq0 = 0LL;
static i64 g_oq1 = 0LL;
static i64 g_nopen = 0LL;
static i64 g_nrej = 0LL;
static i64 e_kind = 0LL;
static i64 g_kill = 0LL;
static i64 g_ended = 0LL;
static i64 g_stepped = 0LL;
static i64 g_cap = 0LL;
static i64 ag_n0 = 0LL;
static i64 ag_n1 = 0LL;
static i64 u__orders_count = 0LL;
static i64 u__last_entry_time = 0LL;
static i64 u__channel_ready = 0LL;
static i64 u__last_calc_time = 0LL;
static i64 u__cancel_cnt = 0LL;
static i64 u_l_do_calc_signal = 0LL;
static i64 sg_bid_qty = 0LL;
static i64 sg_ask_qty = 0LL;
static i64 sg_tick_time = 0LL;
static i64 ok2 = 1LL;
static void tv_chk_0(int c) {
#line 18 "/home/ezudheen/workspace/projects/program_verifier/v9/importer/examples/real_wondertrader_hft/hft.gts"
    __VERIFIER_assert(c || !__VERIFIER_nondet_bool());
}
#line 100000 "<giolit-trade-model>"
int main(void) {
    i64 f_q = 0;
    i64 f_px = 0;
    i64 r_q = 0;
    i64 c_side = 0;
    i64 c_qty = 0;
    i64 c_px = 0;
    i64 d_t = 0;
    i64 c_rej = 0;
    i64 a_st = 0;
    i64 a_side = 0;
    i64 a_qty = 0;
    i64 a_lv = 0;
    i64 a_px = 0;
    i64 a_lq = 0;
    i64 a_lpx = 0;
    i64 l_v_now_2_1 = 0;
    i64 l_v_curMin_3_2 = 0;
    i64 rw3 = 0;
    i64 rw4 = 0;
    i64 rw5 = 0;
    i64 rw6 = 0;
    i64 rw7 = 0;
    i64 rw8 = 0;
    i64 rw9 = 0;
    i64 rc10 = 0;
    i64 rc11 = 0;
    i64 rw12 = 0;
    i64 rc13 = 0;
    i64 rc14 = 0;
    i64 rc15 = 0;
    i64 rc16 = 0;
    i64 rc17 = 0;
    i64 ri18 = 0;
    i64 ri19 = 0;
    i64 l_v_now_1_20 = 0;
    i64 ma21 = 0;
    i64 mb22 = 0;
    i64 mn23 = 0;
    i64 ma24 = 0;
    i64 mb25 = 0;
    i64 mn26 = 0;
    i64 l_v_now_1_27 = 0;
    i64 l_v_curMin_2_28 = 0;
    i64 rw29 = 0;
    i64 rw30 = 0;
    i64 rw31 = 0;
    i64 rw32 = 0;
    i64 rw33 = 0;
    i64 rw34 = 0;
    i64 rw35 = 0;
    i64 rc36 = 0;
    i64 rc37 = 0;
    i64 rw38 = 0;
    i64 rc39 = 0;
    i64 rc40 = 0;
    i64 rc41 = 0;
    i64 rc42 = 0;
    i64 rc43 = 0;
    i64 ri44 = 0;
    i64 ri45 = 0;
    i64 rw46 = 0;
    i64 rc47 = 0;
    i64 l_v_now_1_48 = 0;
    i64 l_v_curMin_2_49 = 0;
    i64 rw50 = 0;
    i64 rw51 = 0;
    i64 rw52 = 0;
    i64 rw53 = 0;
    i64 rw54 = 0;
    i64 rw55 = 0;
    i64 rw56 = 0;
    i64 rc57 = 0;
    i64 rc58 = 0;
    i64 rw59 = 0;
    i64 rc60 = 0;
    i64 rc61 = 0;
    i64 rc62 = 0;
    i64 rc63 = 0;
    i64 rc64 = 0;
    i64 ri65 = 0;
    i64 ri66 = 0;
    i64 l_v_now_1_67 = 0;
    i64 l_v_curMin_2_68 = 0;
    i64 rw69 = 0;
    i64 rw70 = 0;
    i64 rw71 = 0;
    i64 rw72 = 0;
    i64 rw73 = 0;
    i64 rw74 = 0;
    i64 rw75 = 0;
    i64 rc76 = 0;
    i64 rc77 = 0;
    i64 rw78 = 0;
    i64 rc79 = 0;
    i64 rc80 = 0;
    i64 rc81 = 0;
    i64 rc82 = 0;
    i64 rc83 = 0;
    i64 ri84 = 0;
    i64 ri85 = 0;
    i64 l_v_now_1_86 = 0;
    i64 l_v_curMin_2_87 = 0;
    i64 rw88 = 0;
    i64 rw89 = 0;
    i64 rw90 = 0;
    i64 rw91 = 0;
    i64 rw92 = 0;
    i64 rw93 = 0;
    i64 rw94 = 0;
    i64 rc95 = 0;
    i64 rc96 = 0;
    i64 rw97 = 0;
    i64 rc98 = 0;
    i64 rc99 = 0;
    i64 rc100 = 0;
    i64 rc101 = 0;
    i64 rc102 = 0;
    i64 ri103 = 0;
    i64 ri104 = 0;
    g_bid = tv_nd(15000LL, 25000LL);
    g_ask = tv_nd(15000LL, 25000LL);
    g_last = tv_nd(15000LL, 25000LL);
    sg_bid_qty = tv_nd(1LL, 1000LL);
    sg_ask_qty = tv_nd(1LL, 1000LL);
    sg_tick_time = tv_nd(0LL, 235959999LL);
    u__orders_count = 0LL;
    u__last_entry_time = (-1LL);
    u__channel_ready = 0LL;
    u__last_calc_time = 0LL;
    u__cancel_cnt = 0LL;
    u_l_do_calc_signal = 0LL;
    __VERIFIER_assume((g_bid < g_ask));
    if (1LL) {
        u__channel_ready = 1LL;
    }
    while (1) {
#line 1 "<giolit-cycle>"
        __VERIFIER_assume(1);
#line 200000 "<giolit-trade-model>"
        __VERIFIER_assume((u__orders_count == g_nopen));
        tv_chk_0((ok2 != 0LL));
        ok2 = 1LL;
        __VERIFIER_assume(((g_ended == 0LL) && (g_cap == 0LL)));
        d_t = tv_nd(0LL, 1000000000000LL);
        g_time = (g_time + d_t);
        if (__VERIFIER_nondet_bool()) {
            g_bid = tv_nd(15000LL, 25000LL);
            g_ask = tv_nd(15000LL, 25000LL);
            g_last = tv_nd(15000LL, 25000LL);
            sg_bid_qty = tv_nd(1LL, 1000LL);
            sg_ask_qty = tv_nd(1LL, 1000LL);
            sg_tick_time = tv_nd(0LL, 235959999LL);
            r_q = tv_nd(0LL, 1000LL);
            g_vol = (g_vol + r_q);
            __VERIFIER_assume((g_bid < g_ask));
            e_kind = 8LL;
            if (1LL) {
                if ((!(u__orders_count == 0LL))) {
                    if (((!(u__orders_count == 0LL)) && (u__last_entry_time != (-1LL)))) {
                        l_v_now_1_20 = (g_time + 1700000000000LL);
                        if ((((0LL <= (l_v_now_1_20 - u__last_entry_time)) && (5000LL <= (l_v_now_1_20 - u__last_entry_time))) || (!(0LL <= (l_v_now_1_20 - u__last_entry_time))))) {
                            u__cancel_cnt = (u__cancel_cnt + u__orders_count);
                        }
                    }
                } else {
                    if ((u__channel_ready != 0LL)) {
                        l_v_now_2_1 = (g_time + 1700000000000LL);
                        if ((!((0LL <= (l_v_now_2_1 - u__last_entry_time)) && ((l_v_now_2_1 - u__last_entry_time) <= 30000LL)))) {
                            l_v_curMin_3_2 = (sg_tick_time / 100000LL);
                            if ((u__last_calc_time < l_v_curMin_3_2)) {
                                u__last_calc_time = l_v_curMin_3_2;
                            }
                            u_l_do_calc_signal = 0LL;
                            rw3 = g_last;
                            __VERIFIER_assume_implied(15000LL, rw3);
                            __VERIFIER_assume_implied(rw3, 25000LL);
                            rw4 = g_bid;
                            __VERIFIER_assume_implied(15000LL, rw4);
                            __VERIFIER_assume_implied(rw4, 25000LL);
                            rw5 = sg_ask_qty;
                            __VERIFIER_assume_implied(1LL, rw5);
                            __VERIFIER_assume_implied(rw5, 1000LL);
                            rw6 = g_ask;
                            __VERIFIER_assume_implied(15000LL, rw6);
                            __VERIFIER_assume_implied(rw6, 25000LL);
                            rw7 = sg_bid_qty;
                            __VERIFIER_assume_implied(1LL, rw7);
                            __VERIFIER_assume_implied(rw7, 1000LL);
                            rw8 = sg_bid_qty;
                            __VERIFIER_assume_implied(1LL, rw8);
                            __VERIFIER_assume_implied(rw8, 1000LL);
                            rw9 = sg_ask_qty;
                            __VERIFIER_assume_implied(1LL, rw9);
                            __VERIFIER_assume_implied(rw9, 1000LL);
                            rc10 = tv_fp(15, tv_fp(2, tv_fp(10, rw3, 0LL), 4596373779694328218LL), tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(2, tv_fp(10, rw4, 0LL), 4596373779694328218LL), tv_fp(10, rw5, 0LL)), tv_fp(2, tv_fp(2, tv_fp(10, rw6, 0LL), 4596373779694328218LL), tv_fp(10, rw7, 0LL))), tv_fp(0, tv_fp(10, rw8, 0LL), tv_fp(10, rw9, 0LL))));
                            __VERIFIER_assume_implied(((((((((-2LL) * rw4) + ((-63LL) * rw5)) + ((-2LL) * rw6)) + ((-63LL) * rw7)) + (1001LL * rw8)) + (1001LL * rw9)) + (12712366LL * rc10)), 17535097LL);
                            __VERIFIER_assume_implied((((((((2LL * rw4) + (63LL * rw5)) + (2LL * rw6)) + (63LL * rw7)) + ((-1001LL) * rw8)) + ((-1001LL) * rw9)) + ((-12712366LL) * rc10)), 2945346LL);
                            if ((rc10 != 0LL)) {
                                u_l_do_calc_signal = 1LL;
                            } else {
                                rc11 = tv_fp(15, tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(2, tv_fp(10, rw4, 0LL), 4596373779694328218LL), tv_fp(10, rw5, 0LL)), tv_fp(2, tv_fp(2, tv_fp(10, rw6, 0LL), 4596373779694328218LL), tv_fp(10, rw7, 0LL))), tv_fp(0, tv_fp(10, rw8, 0LL), tv_fp(10, rw9, 0LL))), tv_fp(2, tv_fp(10, rw3, 0LL), 4596373779694328218LL));
                                __VERIFIER_assume_implied((((((((2LL * rw4) + (63LL * rw5)) + (2LL * rw6)) + (63LL * rw7)) + ((-1001LL) * rw8)) + ((-1001LL) * rw9)) + (12712366LL * rc11)), 15657713LL);
                                __VERIFIER_assume_implied(((((((((-2LL) * rw4) + ((-63LL) * rw5)) + ((-2LL) * rw6)) + ((-63LL) * rw7)) + (1001LL * rw8)) + (1001LL * rw9)) + ((-12712366LL) * rc11)), 4822731LL);
                                if ((rc11 != 0LL)) {
                                    u_l_do_calc_signal = (-1LL);
                                }
                            }
                            if ((u_l_do_calc_signal != 0LL)) {
                                rw12 = g_pos;
                                rc13 = tv_fp(16, tv_fp(1, tv_fp(10, rw12, 0LL), 0LL), 0LL);
                                if (((0LL < u_l_do_calc_signal) && (rc13 != 0LL))) {
                                    ri19 = tv_fp(13, tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(10, rw3, 0LL), 4596373779694328218LL), tv_fp(2, 4596373779694328218LL, 4611686018427387904LL)), 4596373779694328218LL), 0LL);
                                    __VERIFIER_assume_implied(0LL, ri19);
                                    __VERIFIER_assume_implied((((-32LL) * rw3) + (32LL * ri19)), 81LL);
                                    __VERIFIER_assume_implied(((32LL * rw3) + ((-32LL) * ri19)), (-47LL));
                                    c_side = 0LL;
                                    c_qty = 1LL;
                                    c_px = ri19;
                                    c_rej = 0LL;
                                    if ((0LL < c_qty)) {
                                        if ((c_rej != 0LL)) {
                                            g_nrej = (g_nrej + 1LL);
                                        } else {
                                            if ((c_side == 0LL)) {
                                                ag_n0 = (ag_n0 + 1LL);
                                            } else {
                                                ag_n1 = (ag_n1 + 1LL);
                                            }
                                            if ((c_side == 0LL)) {
                                                g_oq0 = (g_oq0 + c_qty);
                                            } else {
                                                g_oq1 = (g_oq1 + c_qty);
                                            }
                                            g_nopen = (g_nopen + 1LL);
                                            if (0LL) {
                                                ok2 = 0LL;
                                            }
                                        }
                                    }
                                    u__orders_count = (u__orders_count + 1LL);
                                    u__last_entry_time = l_v_now_2_1;
                                } else {
                                    rc14 = tv_fp(15, 0LL, tv_fp(1, tv_fp(10, rw12, 0LL), 0LL));
                                    rc15 = tv_fp(17, tv_fp(1, tv_fp(10, rw12, 0LL), 0LL), 0LL);
                                    rc16 = tv_fp(15, 0LL, tv_fp(1, tv_fp(10, rw12, 0LL), 0LL));
                                    rc17 = tv_fp(17, tv_fp(1, tv_fp(10, rw12, 0LL), 0LL), 0LL);
                                    if (((u_l_do_calc_signal < 0LL) && ((rc16 != 0LL) || (rc17 != 0LL)))) {
                                        ri18 = tv_fp(13, tv_fp(3, tv_fp(1, tv_fp(2, tv_fp(10, rw3, 0LL), 4596373779694328218LL), tv_fp(2, 4596373779694328218LL, 4611686018427387904LL)), 4596373779694328218LL), 0LL);
                                        __VERIFIER_assume_implied((((-32LL) * rw3) + (32LL * ri18)), (-47LL));
                                        __VERIFIER_assume_implied(((32LL * rw3) + ((-32LL) * ri18)), 81LL);
                                        c_side = 1LL;
                                        c_qty = 1LL;
                                        c_px = ri18;
                                        c_rej = 0LL;
                                        if ((0LL < c_qty)) {
                                            if ((c_rej != 0LL)) {
                                                g_nrej = (g_nrej + 1LL);
                                            } else {
                                                if ((c_side == 0LL)) {
                                                    ag_n0 = (ag_n0 + 1LL);
                                                } else {
                                                    ag_n1 = (ag_n1 + 1LL);
                                                }
                                                if ((c_side == 0LL)) {
                                                    g_oq0 = (g_oq0 + c_qty);
                                                } else {
                                                    g_oq1 = (g_oq1 + c_qty);
                                                }
                                                g_nopen = (g_nopen + 1LL);
                                                if (0LL) {
                                                    ok2 = 0LL;
                                                }
                                            }
                                        }
                                        u__orders_count = (u__orders_count + 1LL);
                                        u__last_entry_time = l_v_now_2_1;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        else if (__VERIFIER_nondet_bool()) {
            e_kind = 9LL;
        }
        else {
            if (__VERIFIER_nondet_bool()) {
                if (__VERIFIER_nondet_bool()) {
                    __VERIFIER_assume((1LL <= ag_n0));
                    f_q = tv_nd(1LL, ((g_oq0 - ag_n0) + 1LL));
                    __VERIFIER_assume((f_q <= 100LL));
                    f_px = tv_nd(15000LL, 25000LL);
                    a_side = 0LL;
                    a_st = 6LL;
                    a_qty = tv_nd(1LL, 100LL);
                    a_lv = tv_nd(0LL, a_qty);
                    a_px = tv_nd((-1LL), 25000LL);
                    a_lq = 0LL;
                    a_lpx = 0LL;
                    a_lq = f_q;
                    a_lpx = f_px;
                    if (__VERIFIER_nondet_bool()) {
                        __VERIFIER_assume(((g_oq0 - f_q) <= (100LL * (ag_n0 - 1LL))));
                        g_nopen = (g_nopen + (-1LL));
                        ag_n0 = (ag_n0 - 1LL);
                        a_st = 1LL;
                        a_lv = 0LL;
                        __VERIFIER_assume((f_q <= a_qty));
                    }
                    else {
                        __VERIFIER_assume((1LL <= a_lv));
                        __VERIFIER_assume(((f_q + a_lv) <= a_qty));
                    }
                    g_oq0 = (g_oq0 - f_q);
                    __VERIFIER_assume((ag_n0 <= g_oq0));
                    __VERIFIER_assume(((0LL < ag_n0) || (g_oq0 == 0LL)));
                    g_pos = (g_pos + f_q);
                    g_bought = (g_bought + f_q);
                    g_vol = (g_vol + f_q);
                    ma21 = f_q;
                    mb22 = f_px;
                    mn23 = (ma21 * mb22);
                    __VERIFIER_assume_implied(((mb22 + (15000LL * ma21)) - 15000LL), mn23);
                    __VERIFIER_assume_implied((((100LL * mb22) + (25000LL * ma21)) - 2500000LL), mn23);
                    __VERIFIER_assume_implied(mn23, (((100LL * mb22) + (15000LL * ma21)) - 1500000LL));
                    __VERIFIER_assume_implied(mn23, ((mb22 + (25000LL * ma21)) - 25000LL));
                    g_cash = (g_cash - (20LL * mn23));
                    e_kind = 3LL;
                }
                else if (__VERIFIER_nondet_bool()) {
                    __VERIFIER_assume((1LL <= ag_n0));
                    a_side = 0LL;
                    a_st = 5LL;
                    a_qty = tv_nd(1LL, 100LL);
                    a_lv = tv_nd(0LL, a_qty);
                    a_px = tv_nd((-1LL), 25000LL);
                    a_lq = 0LL;
                    a_lpx = 0LL;
                    e_kind = 1LL;
                }
                else if (__VERIFIER_nondet_bool()) {
                    __VERIFIER_assume((1LL <= ag_n0));
                    r_q = tv_nd(1LL, ((g_oq0 - ag_n0) + 1LL));
                    __VERIFIER_assume(((g_oq0 - r_q) <= (100LL * (ag_n0 - 1LL))));
                    g_nopen = (g_nopen + (-1LL));
                    ag_n0 = (ag_n0 - 1LL);
                    g_oq0 = (g_oq0 - r_q);
                    __VERIFIER_assume((ag_n0 <= g_oq0));
                    __VERIFIER_assume(((0LL < ag_n0) || (g_oq0 == 0LL)));
                    __VERIFIER_assume(((1LL <= r_q) && (r_q <= 100LL)));
                    a_side = 0LL;
                    a_st = 2LL;
                    a_qty = r_q;
                    a_lv = r_q;
                    a_px = tv_nd((-1LL), 25000LL);
                    a_lq = 0LL;
                    a_lpx = 0LL;
                    e_kind = 2LL;
                }
                else if (__VERIFIER_nondet_bool()) {
                    __VERIFIER_assume((1LL <= ag_n0));
                    r_q = tv_nd(1LL, ((g_oq0 - ag_n0) + 1LL));
                    __VERIFIER_assume(((g_oq0 - r_q) <= (100LL * (ag_n0 - 1LL))));
                    g_nopen = (g_nopen + (-1LL));
                    ag_n0 = (ag_n0 - 1LL);
                    g_oq0 = (g_oq0 - r_q);
                    __VERIFIER_assume((ag_n0 <= g_oq0));
                    __VERIFIER_assume(((0LL < ag_n0) || (g_oq0 == 0LL)));
                    a_side = 0LL;
                    a_st = 3LL;
                    a_qty = tv_nd(1LL, 100LL);
                    a_lv = r_q;
                    a_px = tv_nd((-1LL), 25000LL);
                    a_lq = 0LL;
                    a_lpx = 0LL;
                    __VERIFIER_assume((r_q <= a_qty));
                    e_kind = 4LL;
                }
                else {
                    __VERIFIER_assume((1LL <= ag_n0));
                    a_side = 0LL;
                    a_st = 5LL;
                    a_qty = tv_nd(1LL, 100LL);
                    a_lv = tv_nd(0LL, a_qty);
                    a_px = tv_nd((-1LL), 25000LL);
                    a_lq = 0LL;
                    a_lpx = 0LL;
                    e_kind = 5LL;
                }
            }
            else {
                if (__VERIFIER_nondet_bool()) {
                    __VERIFIER_assume((1LL <= ag_n1));
                    f_q = tv_nd(1LL, ((g_oq1 - ag_n1) + 1LL));
                    __VERIFIER_assume((f_q <= 100LL));
                    f_px = tv_nd(15000LL, 25000LL);
                    a_side = 1LL;
                    a_st = 6LL;
                    a_qty = tv_nd(1LL, 100LL);
                    a_lv = tv_nd(0LL, a_qty);
                    a_px = tv_nd((-1LL), 25000LL);
                    a_lq = 0LL;
                    a_lpx = 0LL;
                    a_lq = f_q;
                    a_lpx = f_px;
                    if (__VERIFIER_nondet_bool()) {
                        __VERIFIER_assume(((g_oq1 - f_q) <= (100LL * (ag_n1 - 1LL))));
                        g_nopen = (g_nopen + (-1LL));
                        ag_n1 = (ag_n1 - 1LL);
                        a_st = 1LL;
                        a_lv = 0LL;
                        __VERIFIER_assume((f_q <= a_qty));
                    }
                    else {
                        __VERIFIER_assume((1LL <= a_lv));
                        __VERIFIER_assume(((f_q + a_lv) <= a_qty));
                    }
                    g_oq1 = (g_oq1 - f_q);
                    __VERIFIER_assume((ag_n1 <= g_oq1));
                    __VERIFIER_assume(((0LL < ag_n1) || (g_oq1 == 0LL)));
                    g_pos = (g_pos - f_q);
                    g_sold = (g_sold + f_q);
                    g_vol = (g_vol + f_q);
                    ma24 = f_q;
                    mb25 = f_px;
                    mn26 = (ma24 * mb25);
                    __VERIFIER_assume_implied(((mb25 + (15000LL * ma24)) - 15000LL), mn26);
                    __VERIFIER_assume_implied((((100LL * mb25) + (25000LL * ma24)) - 2500000LL), mn26);
                    __VERIFIER_assume_implied(mn26, (((100LL * mb25) + (15000LL * ma24)) - 1500000LL));
                    __VERIFIER_assume_implied(mn26, ((mb25 + (25000LL * ma24)) - 25000LL));
                    g_cash = (g_cash + (20LL * mn26));
                    e_kind = 3LL;
                }
                else if (__VERIFIER_nondet_bool()) {
                    __VERIFIER_assume((1LL <= ag_n1));
                    a_side = 1LL;
                    a_st = 5LL;
                    a_qty = tv_nd(1LL, 100LL);
                    a_lv = tv_nd(0LL, a_qty);
                    a_px = tv_nd((-1LL), 25000LL);
                    a_lq = 0LL;
                    a_lpx = 0LL;
                    e_kind = 1LL;
                }
                else if (__VERIFIER_nondet_bool()) {
                    __VERIFIER_assume((1LL <= ag_n1));
                    r_q = tv_nd(1LL, ((g_oq1 - ag_n1) + 1LL));
                    __VERIFIER_assume(((g_oq1 - r_q) <= (100LL * (ag_n1 - 1LL))));
                    g_nopen = (g_nopen + (-1LL));
                    ag_n1 = (ag_n1 - 1LL);
                    g_oq1 = (g_oq1 - r_q);
                    __VERIFIER_assume((ag_n1 <= g_oq1));
                    __VERIFIER_assume(((0LL < ag_n1) || (g_oq1 == 0LL)));
                    __VERIFIER_assume(((1LL <= r_q) && (r_q <= 100LL)));
                    a_side = 1LL;
                    a_st = 2LL;
                    a_qty = r_q;
                    a_lv = r_q;
                    a_px = tv_nd((-1LL), 25000LL);
                    a_lq = 0LL;
                    a_lpx = 0LL;
                    e_kind = 2LL;
                }
                else if (__VERIFIER_nondet_bool()) {
                    __VERIFIER_assume((1LL <= ag_n1));
                    r_q = tv_nd(1LL, ((g_oq1 - ag_n1) + 1LL));
                    __VERIFIER_assume(((g_oq1 - r_q) <= (100LL * (ag_n1 - 1LL))));
                    g_nopen = (g_nopen + (-1LL));
                    ag_n1 = (ag_n1 - 1LL);
                    g_oq1 = (g_oq1 - r_q);
                    __VERIFIER_assume((ag_n1 <= g_oq1));
                    __VERIFIER_assume(((0LL < ag_n1) || (g_oq1 == 0LL)));
                    a_side = 1LL;
                    a_st = 3LL;
                    a_qty = tv_nd(1LL, 100LL);
                    a_lv = r_q;
                    a_px = tv_nd((-1LL), 25000LL);
                    a_lq = 0LL;
                    a_lpx = 0LL;
                    __VERIFIER_assume((r_q <= a_qty));
                    e_kind = 4LL;
                }
                else {
                    __VERIFIER_assume((1LL <= ag_n1));
                    a_side = 1LL;
                    a_st = 5LL;
                    a_qty = tv_nd(1LL, 100LL);
                    a_lv = tv_nd(0LL, a_qty);
                    a_px = tv_nd((-1LL), 25000LL);
                    a_lq = 0LL;
                    a_lpx = 0LL;
                    e_kind = 5LL;
                }
            }
            if ((e_kind == 4LL)) {
                if (1LL) {
                    u__orders_count = (u__orders_count - 1LL);
                    if ((0LL < u__cancel_cnt)) {
                        u__cancel_cnt = (u__cancel_cnt - 1LL);
                    }
                    l_v_now_1_27 = (g_time + 1700000000000LL);
                    if ((!((0LL <= (l_v_now_1_27 - u__last_entry_time)) && ((l_v_now_1_27 - u__last_entry_time) <= 30000LL)))) {
                        l_v_curMin_2_28 = (sg_tick_time / 100000LL);
                        if ((u__last_calc_time < l_v_curMin_2_28)) {
                            u__last_calc_time = l_v_curMin_2_28;
                        }
                        u_l_do_calc_signal = 0LL;
                        rw29 = g_last;
                        __VERIFIER_assume_implied(15000LL, rw29);
                        __VERIFIER_assume_implied(rw29, 25000LL);
                        rw30 = g_bid;
                        __VERIFIER_assume_implied(15000LL, rw30);
                        __VERIFIER_assume_implied(rw30, 25000LL);
                        rw31 = sg_ask_qty;
                        __VERIFIER_assume_implied(1LL, rw31);
                        __VERIFIER_assume_implied(rw31, 1000LL);
                        rw32 = g_ask;
                        __VERIFIER_assume_implied(15000LL, rw32);
                        __VERIFIER_assume_implied(rw32, 25000LL);
                        rw33 = sg_bid_qty;
                        __VERIFIER_assume_implied(1LL, rw33);
                        __VERIFIER_assume_implied(rw33, 1000LL);
                        rw34 = sg_bid_qty;
                        __VERIFIER_assume_implied(1LL, rw34);
                        __VERIFIER_assume_implied(rw34, 1000LL);
                        rw35 = sg_ask_qty;
                        __VERIFIER_assume_implied(1LL, rw35);
                        __VERIFIER_assume_implied(rw35, 1000LL);
                        rc36 = tv_fp(15, tv_fp(2, tv_fp(10, rw29, 0LL), 4596373779694328218LL), tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(2, tv_fp(10, rw30, 0LL), 4596373779694328218LL), tv_fp(10, rw31, 0LL)), tv_fp(2, tv_fp(2, tv_fp(10, rw32, 0LL), 4596373779694328218LL), tv_fp(10, rw33, 0LL))), tv_fp(0, tv_fp(10, rw34, 0LL), tv_fp(10, rw35, 0LL))));
                        __VERIFIER_assume_implied(((((((((-2LL) * rw30) + ((-63LL) * rw31)) + ((-2LL) * rw32)) + ((-63LL) * rw33)) + (1001LL * rw34)) + (1001LL * rw35)) + (12712366LL * rc36)), 17535097LL);
                        __VERIFIER_assume_implied((((((((2LL * rw30) + (63LL * rw31)) + (2LL * rw32)) + (63LL * rw33)) + ((-1001LL) * rw34)) + ((-1001LL) * rw35)) + ((-12712366LL) * rc36)), 2945346LL);
                        if ((rc36 != 0LL)) {
                            u_l_do_calc_signal = 1LL;
                        } else {
                            rc37 = tv_fp(15, tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(2, tv_fp(10, rw30, 0LL), 4596373779694328218LL), tv_fp(10, rw31, 0LL)), tv_fp(2, tv_fp(2, tv_fp(10, rw32, 0LL), 4596373779694328218LL), tv_fp(10, rw33, 0LL))), tv_fp(0, tv_fp(10, rw34, 0LL), tv_fp(10, rw35, 0LL))), tv_fp(2, tv_fp(10, rw29, 0LL), 4596373779694328218LL));
                            __VERIFIER_assume_implied((((((((2LL * rw30) + (63LL * rw31)) + (2LL * rw32)) + (63LL * rw33)) + ((-1001LL) * rw34)) + ((-1001LL) * rw35)) + (12712366LL * rc37)), 15657713LL);
                            __VERIFIER_assume_implied(((((((((-2LL) * rw30) + ((-63LL) * rw31)) + ((-2LL) * rw32)) + ((-63LL) * rw33)) + (1001LL * rw34)) + (1001LL * rw35)) + ((-12712366LL) * rc37)), 4822731LL);
                            if ((rc37 != 0LL)) {
                                u_l_do_calc_signal = (-1LL);
                            }
                        }
                        if ((u_l_do_calc_signal != 0LL)) {
                            rw38 = g_pos;
                            rc39 = tv_fp(16, tv_fp(1, tv_fp(10, rw38, 0LL), 0LL), 0LL);
                            if (((0LL < u_l_do_calc_signal) && (rc39 != 0LL))) {
                                ri45 = tv_fp(13, tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(10, rw29, 0LL), 4596373779694328218LL), tv_fp(2, 4596373779694328218LL, 4611686018427387904LL)), 4596373779694328218LL), 0LL);
                                __VERIFIER_assume_implied(0LL, ri45);
                                __VERIFIER_assume_implied((((-32LL) * rw29) + (32LL * ri45)), 81LL);
                                __VERIFIER_assume_implied(((32LL * rw29) + ((-32LL) * ri45)), (-47LL));
                                c_side = 0LL;
                                c_qty = 1LL;
                                c_px = ri45;
                                c_rej = 0LL;
                                if ((0LL < c_qty)) {
                                    if ((c_rej != 0LL)) {
                                        g_nrej = (g_nrej + 1LL);
                                    } else {
                                        if ((c_side == 0LL)) {
                                            ag_n0 = (ag_n0 + 1LL);
                                        } else {
                                            ag_n1 = (ag_n1 + 1LL);
                                        }
                                        if ((c_side == 0LL)) {
                                            g_oq0 = (g_oq0 + c_qty);
                                        } else {
                                            g_oq1 = (g_oq1 + c_qty);
                                        }
                                        g_nopen = (g_nopen + 1LL);
                                        if (0LL) {
                                            ok2 = 0LL;
                                        }
                                    }
                                }
                                u__orders_count = (u__orders_count + 1LL);
                                u__last_entry_time = l_v_now_1_27;
                            } else {
                                rc40 = tv_fp(15, 0LL, tv_fp(1, tv_fp(10, rw38, 0LL), 0LL));
                                rc41 = tv_fp(17, tv_fp(1, tv_fp(10, rw38, 0LL), 0LL), 0LL);
                                rc42 = tv_fp(15, 0LL, tv_fp(1, tv_fp(10, rw38, 0LL), 0LL));
                                rc43 = tv_fp(17, tv_fp(1, tv_fp(10, rw38, 0LL), 0LL), 0LL);
                                if (((u_l_do_calc_signal < 0LL) && ((rc42 != 0LL) || (rc43 != 0LL)))) {
                                    ri44 = tv_fp(13, tv_fp(3, tv_fp(1, tv_fp(2, tv_fp(10, rw29, 0LL), 4596373779694328218LL), tv_fp(2, 4596373779694328218LL, 4611686018427387904LL)), 4596373779694328218LL), 0LL);
                                    __VERIFIER_assume_implied((((-32LL) * rw29) + (32LL * ri44)), (-47LL));
                                    __VERIFIER_assume_implied(((32LL * rw29) + ((-32LL) * ri44)), 81LL);
                                    c_side = 1LL;
                                    c_qty = 1LL;
                                    c_px = ri44;
                                    c_rej = 0LL;
                                    if ((0LL < c_qty)) {
                                        if ((c_rej != 0LL)) {
                                            g_nrej = (g_nrej + 1LL);
                                        } else {
                                            if ((c_side == 0LL)) {
                                                ag_n0 = (ag_n0 + 1LL);
                                            } else {
                                                ag_n1 = (ag_n1 + 1LL);
                                            }
                                            if ((c_side == 0LL)) {
                                                g_oq0 = (g_oq0 + c_qty);
                                            } else {
                                                g_oq1 = (g_oq1 + c_qty);
                                            }
                                            g_nopen = (g_nopen + 1LL);
                                            if (0LL) {
                                                ok2 = 0LL;
                                            }
                                        }
                                    }
                                    u__orders_count = (u__orders_count + 1LL);
                                    u__last_entry_time = l_v_now_1_27;
                                }
                            }
                        }
                    }
                }
            }
            if ((e_kind == 3LL)) {
                if (1LL) {
                    rw46 = a_lv;
                    __VERIFIER_assume_implied(0LL, rw46);
                    __VERIFIER_assume_implied(rw46, 100LL);
                    rc47 = tv_fp(17, tv_fp(10, rw46, 0LL), 0LL);
                    if ((rc47 != 0LL)) {
                        u__orders_count = (u__orders_count - 1LL);
                        if ((0LL < u__cancel_cnt)) {
                            u__cancel_cnt = (u__cancel_cnt - 1LL);
                        }
                        l_v_now_1_48 = (g_time + 1700000000000LL);
                        if ((!((0LL <= (l_v_now_1_48 - u__last_entry_time)) && ((l_v_now_1_48 - u__last_entry_time) <= 30000LL)))) {
                            l_v_curMin_2_49 = (sg_tick_time / 100000LL);
                            if ((u__last_calc_time < l_v_curMin_2_49)) {
                                u__last_calc_time = l_v_curMin_2_49;
                            }
                            u_l_do_calc_signal = 0LL;
                            rw50 = g_last;
                            __VERIFIER_assume_implied(15000LL, rw50);
                            __VERIFIER_assume_implied(rw50, 25000LL);
                            rw51 = g_bid;
                            __VERIFIER_assume_implied(15000LL, rw51);
                            __VERIFIER_assume_implied(rw51, 25000LL);
                            rw52 = sg_ask_qty;
                            __VERIFIER_assume_implied(1LL, rw52);
                            __VERIFIER_assume_implied(rw52, 1000LL);
                            rw53 = g_ask;
                            __VERIFIER_assume_implied(15000LL, rw53);
                            __VERIFIER_assume_implied(rw53, 25000LL);
                            rw54 = sg_bid_qty;
                            __VERIFIER_assume_implied(1LL, rw54);
                            __VERIFIER_assume_implied(rw54, 1000LL);
                            rw55 = sg_bid_qty;
                            __VERIFIER_assume_implied(1LL, rw55);
                            __VERIFIER_assume_implied(rw55, 1000LL);
                            rw56 = sg_ask_qty;
                            __VERIFIER_assume_implied(1LL, rw56);
                            __VERIFIER_assume_implied(rw56, 1000LL);
                            rc57 = tv_fp(15, tv_fp(2, tv_fp(10, rw50, 0LL), 4596373779694328218LL), tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(2, tv_fp(10, rw51, 0LL), 4596373779694328218LL), tv_fp(10, rw52, 0LL)), tv_fp(2, tv_fp(2, tv_fp(10, rw53, 0LL), 4596373779694328218LL), tv_fp(10, rw54, 0LL))), tv_fp(0, tv_fp(10, rw55, 0LL), tv_fp(10, rw56, 0LL))));
                            __VERIFIER_assume_implied(((((((((-2LL) * rw51) + ((-63LL) * rw52)) + ((-2LL) * rw53)) + ((-63LL) * rw54)) + (1001LL * rw55)) + (1001LL * rw56)) + (12712366LL * rc57)), 17535097LL);
                            __VERIFIER_assume_implied((((((((2LL * rw51) + (63LL * rw52)) + (2LL * rw53)) + (63LL * rw54)) + ((-1001LL) * rw55)) + ((-1001LL) * rw56)) + ((-12712366LL) * rc57)), 2945346LL);
                            if ((rc57 != 0LL)) {
                                u_l_do_calc_signal = 1LL;
                            } else {
                                rc58 = tv_fp(15, tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(2, tv_fp(10, rw51, 0LL), 4596373779694328218LL), tv_fp(10, rw52, 0LL)), tv_fp(2, tv_fp(2, tv_fp(10, rw53, 0LL), 4596373779694328218LL), tv_fp(10, rw54, 0LL))), tv_fp(0, tv_fp(10, rw55, 0LL), tv_fp(10, rw56, 0LL))), tv_fp(2, tv_fp(10, rw50, 0LL), 4596373779694328218LL));
                                __VERIFIER_assume_implied((((((((2LL * rw51) + (63LL * rw52)) + (2LL * rw53)) + (63LL * rw54)) + ((-1001LL) * rw55)) + ((-1001LL) * rw56)) + (12712366LL * rc58)), 15657713LL);
                                __VERIFIER_assume_implied(((((((((-2LL) * rw51) + ((-63LL) * rw52)) + ((-2LL) * rw53)) + ((-63LL) * rw54)) + (1001LL * rw55)) + (1001LL * rw56)) + ((-12712366LL) * rc58)), 4822731LL);
                                if ((rc58 != 0LL)) {
                                    u_l_do_calc_signal = (-1LL);
                                }
                            }
                            if ((u_l_do_calc_signal != 0LL)) {
                                rw59 = g_pos;
                                rc60 = tv_fp(16, tv_fp(1, tv_fp(10, rw59, 0LL), 0LL), 0LL);
                                if (((0LL < u_l_do_calc_signal) && (rc60 != 0LL))) {
                                    ri66 = tv_fp(13, tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(10, rw50, 0LL), 4596373779694328218LL), tv_fp(2, 4596373779694328218LL, 4611686018427387904LL)), 4596373779694328218LL), 0LL);
                                    __VERIFIER_assume_implied(0LL, ri66);
                                    __VERIFIER_assume_implied((((-32LL) * rw50) + (32LL * ri66)), 81LL);
                                    __VERIFIER_assume_implied(((32LL * rw50) + ((-32LL) * ri66)), (-47LL));
                                    c_side = 0LL;
                                    c_qty = 1LL;
                                    c_px = ri66;
                                    c_rej = 0LL;
                                    if ((0LL < c_qty)) {
                                        if ((c_rej != 0LL)) {
                                            g_nrej = (g_nrej + 1LL);
                                        } else {
                                            if ((c_side == 0LL)) {
                                                ag_n0 = (ag_n0 + 1LL);
                                            } else {
                                                ag_n1 = (ag_n1 + 1LL);
                                            }
                                            if ((c_side == 0LL)) {
                                                g_oq0 = (g_oq0 + c_qty);
                                            } else {
                                                g_oq1 = (g_oq1 + c_qty);
                                            }
                                            g_nopen = (g_nopen + 1LL);
                                            if (0LL) {
                                                ok2 = 0LL;
                                            }
                                        }
                                    }
                                    u__orders_count = (u__orders_count + 1LL);
                                    u__last_entry_time = l_v_now_1_48;
                                } else {
                                    rc61 = tv_fp(15, 0LL, tv_fp(1, tv_fp(10, rw59, 0LL), 0LL));
                                    rc62 = tv_fp(17, tv_fp(1, tv_fp(10, rw59, 0LL), 0LL), 0LL);
                                    rc63 = tv_fp(15, 0LL, tv_fp(1, tv_fp(10, rw59, 0LL), 0LL));
                                    rc64 = tv_fp(17, tv_fp(1, tv_fp(10, rw59, 0LL), 0LL), 0LL);
                                    if (((u_l_do_calc_signal < 0LL) && ((rc63 != 0LL) || (rc64 != 0LL)))) {
                                        ri65 = tv_fp(13, tv_fp(3, tv_fp(1, tv_fp(2, tv_fp(10, rw50, 0LL), 4596373779694328218LL), tv_fp(2, 4596373779694328218LL, 4611686018427387904LL)), 4596373779694328218LL), 0LL);
                                        __VERIFIER_assume_implied((((-32LL) * rw50) + (32LL * ri65)), (-47LL));
                                        __VERIFIER_assume_implied(((32LL * rw50) + ((-32LL) * ri65)), 81LL);
                                        c_side = 1LL;
                                        c_qty = 1LL;
                                        c_px = ri65;
                                        c_rej = 0LL;
                                        if ((0LL < c_qty)) {
                                            if ((c_rej != 0LL)) {
                                                g_nrej = (g_nrej + 1LL);
                                            } else {
                                                if ((c_side == 0LL)) {
                                                    ag_n0 = (ag_n0 + 1LL);
                                                } else {
                                                    ag_n1 = (ag_n1 + 1LL);
                                                }
                                                if ((c_side == 0LL)) {
                                                    g_oq0 = (g_oq0 + c_qty);
                                                } else {
                                                    g_oq1 = (g_oq1 + c_qty);
                                                }
                                                g_nopen = (g_nopen + 1LL);
                                                if (0LL) {
                                                    ok2 = 0LL;
                                                }
                                            }
                                        }
                                        u__orders_count = (u__orders_count + 1LL);
                                        u__last_entry_time = l_v_now_1_48;
                                    }
                                }
                            }
                        }
                    }
                }
                if (1LL) {
                    l_v_now_1_67 = (g_time + 1700000000000LL);
                    if ((!((0LL <= (l_v_now_1_67 - u__last_entry_time)) && ((l_v_now_1_67 - u__last_entry_time) <= 30000LL)))) {
                        l_v_curMin_2_68 = (sg_tick_time / 100000LL);
                        if ((u__last_calc_time < l_v_curMin_2_68)) {
                            u__last_calc_time = l_v_curMin_2_68;
                        }
                        u_l_do_calc_signal = 0LL;
                        rw69 = g_last;
                        __VERIFIER_assume_implied(15000LL, rw69);
                        __VERIFIER_assume_implied(rw69, 25000LL);
                        rw70 = g_bid;
                        __VERIFIER_assume_implied(15000LL, rw70);
                        __VERIFIER_assume_implied(rw70, 25000LL);
                        rw71 = sg_ask_qty;
                        __VERIFIER_assume_implied(1LL, rw71);
                        __VERIFIER_assume_implied(rw71, 1000LL);
                        rw72 = g_ask;
                        __VERIFIER_assume_implied(15000LL, rw72);
                        __VERIFIER_assume_implied(rw72, 25000LL);
                        rw73 = sg_bid_qty;
                        __VERIFIER_assume_implied(1LL, rw73);
                        __VERIFIER_assume_implied(rw73, 1000LL);
                        rw74 = sg_bid_qty;
                        __VERIFIER_assume_implied(1LL, rw74);
                        __VERIFIER_assume_implied(rw74, 1000LL);
                        rw75 = sg_ask_qty;
                        __VERIFIER_assume_implied(1LL, rw75);
                        __VERIFIER_assume_implied(rw75, 1000LL);
                        rc76 = tv_fp(15, tv_fp(2, tv_fp(10, rw69, 0LL), 4596373779694328218LL), tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(2, tv_fp(10, rw70, 0LL), 4596373779694328218LL), tv_fp(10, rw71, 0LL)), tv_fp(2, tv_fp(2, tv_fp(10, rw72, 0LL), 4596373779694328218LL), tv_fp(10, rw73, 0LL))), tv_fp(0, tv_fp(10, rw74, 0LL), tv_fp(10, rw75, 0LL))));
                        __VERIFIER_assume_implied(((((((((-2LL) * rw70) + ((-63LL) * rw71)) + ((-2LL) * rw72)) + ((-63LL) * rw73)) + (1001LL * rw74)) + (1001LL * rw75)) + (12712366LL * rc76)), 17535097LL);
                        __VERIFIER_assume_implied((((((((2LL * rw70) + (63LL * rw71)) + (2LL * rw72)) + (63LL * rw73)) + ((-1001LL) * rw74)) + ((-1001LL) * rw75)) + ((-12712366LL) * rc76)), 2945346LL);
                        if ((rc76 != 0LL)) {
                            u_l_do_calc_signal = 1LL;
                        } else {
                            rc77 = tv_fp(15, tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(2, tv_fp(10, rw70, 0LL), 4596373779694328218LL), tv_fp(10, rw71, 0LL)), tv_fp(2, tv_fp(2, tv_fp(10, rw72, 0LL), 4596373779694328218LL), tv_fp(10, rw73, 0LL))), tv_fp(0, tv_fp(10, rw74, 0LL), tv_fp(10, rw75, 0LL))), tv_fp(2, tv_fp(10, rw69, 0LL), 4596373779694328218LL));
                            __VERIFIER_assume_implied((((((((2LL * rw70) + (63LL * rw71)) + (2LL * rw72)) + (63LL * rw73)) + ((-1001LL) * rw74)) + ((-1001LL) * rw75)) + (12712366LL * rc77)), 15657713LL);
                            __VERIFIER_assume_implied(((((((((-2LL) * rw70) + ((-63LL) * rw71)) + ((-2LL) * rw72)) + ((-63LL) * rw73)) + (1001LL * rw74)) + (1001LL * rw75)) + ((-12712366LL) * rc77)), 4822731LL);
                            if ((rc77 != 0LL)) {
                                u_l_do_calc_signal = (-1LL);
                            }
                        }
                        if ((u_l_do_calc_signal != 0LL)) {
                            rw78 = g_pos;
                            rc79 = tv_fp(16, tv_fp(1, tv_fp(10, rw78, 0LL), 0LL), 0LL);
                            if (((0LL < u_l_do_calc_signal) && (rc79 != 0LL))) {
                                ri85 = tv_fp(13, tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(10, rw69, 0LL), 4596373779694328218LL), tv_fp(2, 4596373779694328218LL, 4611686018427387904LL)), 4596373779694328218LL), 0LL);
                                __VERIFIER_assume_implied(0LL, ri85);
                                __VERIFIER_assume_implied((((-32LL) * rw69) + (32LL * ri85)), 81LL);
                                __VERIFIER_assume_implied(((32LL * rw69) + ((-32LL) * ri85)), (-47LL));
                                c_side = 0LL;
                                c_qty = 1LL;
                                c_px = ri85;
                                c_rej = 0LL;
                                if ((0LL < c_qty)) {
                                    if ((c_rej != 0LL)) {
                                        g_nrej = (g_nrej + 1LL);
                                    } else {
                                        if ((c_side == 0LL)) {
                                            ag_n0 = (ag_n0 + 1LL);
                                        } else {
                                            ag_n1 = (ag_n1 + 1LL);
                                        }
                                        if ((c_side == 0LL)) {
                                            g_oq0 = (g_oq0 + c_qty);
                                        } else {
                                            g_oq1 = (g_oq1 + c_qty);
                                        }
                                        g_nopen = (g_nopen + 1LL);
                                        if (0LL) {
                                            ok2 = 0LL;
                                        }
                                    }
                                }
                                u__orders_count = (u__orders_count + 1LL);
                                u__last_entry_time = l_v_now_1_67;
                            } else {
                                rc80 = tv_fp(15, 0LL, tv_fp(1, tv_fp(10, rw78, 0LL), 0LL));
                                rc81 = tv_fp(17, tv_fp(1, tv_fp(10, rw78, 0LL), 0LL), 0LL);
                                rc82 = tv_fp(15, 0LL, tv_fp(1, tv_fp(10, rw78, 0LL), 0LL));
                                rc83 = tv_fp(17, tv_fp(1, tv_fp(10, rw78, 0LL), 0LL), 0LL);
                                if (((u_l_do_calc_signal < 0LL) && ((rc82 != 0LL) || (rc83 != 0LL)))) {
                                    ri84 = tv_fp(13, tv_fp(3, tv_fp(1, tv_fp(2, tv_fp(10, rw69, 0LL), 4596373779694328218LL), tv_fp(2, 4596373779694328218LL, 4611686018427387904LL)), 4596373779694328218LL), 0LL);
                                    __VERIFIER_assume_implied((((-32LL) * rw69) + (32LL * ri84)), (-47LL));
                                    __VERIFIER_assume_implied(((32LL * rw69) + ((-32LL) * ri84)), 81LL);
                                    c_side = 1LL;
                                    c_qty = 1LL;
                                    c_px = ri84;
                                    c_rej = 0LL;
                                    if ((0LL < c_qty)) {
                                        if ((c_rej != 0LL)) {
                                            g_nrej = (g_nrej + 1LL);
                                        } else {
                                            if ((c_side == 0LL)) {
                                                ag_n0 = (ag_n0 + 1LL);
                                            } else {
                                                ag_n1 = (ag_n1 + 1LL);
                                            }
                                            if ((c_side == 0LL)) {
                                                g_oq0 = (g_oq0 + c_qty);
                                            } else {
                                                g_oq1 = (g_oq1 + c_qty);
                                            }
                                            g_nopen = (g_nopen + 1LL);
                                            if (0LL) {
                                                ok2 = 0LL;
                                            }
                                        }
                                    }
                                    u__orders_count = (u__orders_count + 1LL);
                                    u__last_entry_time = l_v_now_1_67;
                                }
                            }
                        }
                    }
                }
            }
            if ((e_kind == 2LL)) {
                if (1LL) {
                    u__orders_count = (u__orders_count - 1LL);
                    if ((0LL < u__cancel_cnt)) {
                        u__cancel_cnt = (u__cancel_cnt - 1LL);
                    }
                    l_v_now_1_86 = (g_time + 1700000000000LL);
                    if ((!((0LL <= (l_v_now_1_86 - u__last_entry_time)) && ((l_v_now_1_86 - u__last_entry_time) <= 30000LL)))) {
                        l_v_curMin_2_87 = (sg_tick_time / 100000LL);
                        if ((u__last_calc_time < l_v_curMin_2_87)) {
                            u__last_calc_time = l_v_curMin_2_87;
                        }
                        u_l_do_calc_signal = 0LL;
                        rw88 = g_last;
                        __VERIFIER_assume_implied(15000LL, rw88);
                        __VERIFIER_assume_implied(rw88, 25000LL);
                        rw89 = g_bid;
                        __VERIFIER_assume_implied(15000LL, rw89);
                        __VERIFIER_assume_implied(rw89, 25000LL);
                        rw90 = sg_ask_qty;
                        __VERIFIER_assume_implied(1LL, rw90);
                        __VERIFIER_assume_implied(rw90, 1000LL);
                        rw91 = g_ask;
                        __VERIFIER_assume_implied(15000LL, rw91);
                        __VERIFIER_assume_implied(rw91, 25000LL);
                        rw92 = sg_bid_qty;
                        __VERIFIER_assume_implied(1LL, rw92);
                        __VERIFIER_assume_implied(rw92, 1000LL);
                        rw93 = sg_bid_qty;
                        __VERIFIER_assume_implied(1LL, rw93);
                        __VERIFIER_assume_implied(rw93, 1000LL);
                        rw94 = sg_ask_qty;
                        __VERIFIER_assume_implied(1LL, rw94);
                        __VERIFIER_assume_implied(rw94, 1000LL);
                        rc95 = tv_fp(15, tv_fp(2, tv_fp(10, rw88, 0LL), 4596373779694328218LL), tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(2, tv_fp(10, rw89, 0LL), 4596373779694328218LL), tv_fp(10, rw90, 0LL)), tv_fp(2, tv_fp(2, tv_fp(10, rw91, 0LL), 4596373779694328218LL), tv_fp(10, rw92, 0LL))), tv_fp(0, tv_fp(10, rw93, 0LL), tv_fp(10, rw94, 0LL))));
                        __VERIFIER_assume_implied(((((((((-2LL) * rw89) + ((-63LL) * rw90)) + ((-2LL) * rw91)) + ((-63LL) * rw92)) + (1001LL * rw93)) + (1001LL * rw94)) + (12712366LL * rc95)), 17535097LL);
                        __VERIFIER_assume_implied((((((((2LL * rw89) + (63LL * rw90)) + (2LL * rw91)) + (63LL * rw92)) + ((-1001LL) * rw93)) + ((-1001LL) * rw94)) + ((-12712366LL) * rc95)), 2945346LL);
                        if ((rc95 != 0LL)) {
                            u_l_do_calc_signal = 1LL;
                        } else {
                            rc96 = tv_fp(15, tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(2, tv_fp(10, rw89, 0LL), 4596373779694328218LL), tv_fp(10, rw90, 0LL)), tv_fp(2, tv_fp(2, tv_fp(10, rw91, 0LL), 4596373779694328218LL), tv_fp(10, rw92, 0LL))), tv_fp(0, tv_fp(10, rw93, 0LL), tv_fp(10, rw94, 0LL))), tv_fp(2, tv_fp(10, rw88, 0LL), 4596373779694328218LL));
                            __VERIFIER_assume_implied((((((((2LL * rw89) + (63LL * rw90)) + (2LL * rw91)) + (63LL * rw92)) + ((-1001LL) * rw93)) + ((-1001LL) * rw94)) + (12712366LL * rc96)), 15657713LL);
                            __VERIFIER_assume_implied(((((((((-2LL) * rw89) + ((-63LL) * rw90)) + ((-2LL) * rw91)) + ((-63LL) * rw92)) + (1001LL * rw93)) + (1001LL * rw94)) + ((-12712366LL) * rc96)), 4822731LL);
                            if ((rc96 != 0LL)) {
                                u_l_do_calc_signal = (-1LL);
                            }
                        }
                        if ((u_l_do_calc_signal != 0LL)) {
                            rw97 = g_pos;
                            rc98 = tv_fp(16, tv_fp(1, tv_fp(10, rw97, 0LL), 0LL), 0LL);
                            if (((0LL < u_l_do_calc_signal) && (rc98 != 0LL))) {
                                ri104 = tv_fp(13, tv_fp(3, tv_fp(0, tv_fp(2, tv_fp(10, rw88, 0LL), 4596373779694328218LL), tv_fp(2, 4596373779694328218LL, 4611686018427387904LL)), 4596373779694328218LL), 0LL);
                                __VERIFIER_assume_implied(0LL, ri104);
                                __VERIFIER_assume_implied((((-32LL) * rw88) + (32LL * ri104)), 81LL);
                                __VERIFIER_assume_implied(((32LL * rw88) + ((-32LL) * ri104)), (-47LL));
                                c_side = 0LL;
                                c_qty = 1LL;
                                c_px = ri104;
                                c_rej = 0LL;
                                if ((0LL < c_qty)) {
                                    if ((c_rej != 0LL)) {
                                        g_nrej = (g_nrej + 1LL);
                                    } else {
                                        if ((c_side == 0LL)) {
                                            ag_n0 = (ag_n0 + 1LL);
                                        } else {
                                            ag_n1 = (ag_n1 + 1LL);
                                        }
                                        if ((c_side == 0LL)) {
                                            g_oq0 = (g_oq0 + c_qty);
                                        } else {
                                            g_oq1 = (g_oq1 + c_qty);
                                        }
                                        g_nopen = (g_nopen + 1LL);
                                        if (0LL) {
                                            ok2 = 0LL;
                                        }
                                    }
                                }
                                u__orders_count = (u__orders_count + 1LL);
                                u__last_entry_time = l_v_now_1_86;
                            } else {
                                rc99 = tv_fp(15, 0LL, tv_fp(1, tv_fp(10, rw97, 0LL), 0LL));
                                rc100 = tv_fp(17, tv_fp(1, tv_fp(10, rw97, 0LL), 0LL), 0LL);
                                rc101 = tv_fp(15, 0LL, tv_fp(1, tv_fp(10, rw97, 0LL), 0LL));
                                rc102 = tv_fp(17, tv_fp(1, tv_fp(10, rw97, 0LL), 0LL), 0LL);
                                if (((u_l_do_calc_signal < 0LL) && ((rc101 != 0LL) || (rc102 != 0LL)))) {
                                    ri103 = tv_fp(13, tv_fp(3, tv_fp(1, tv_fp(2, tv_fp(10, rw88, 0LL), 4596373779694328218LL), tv_fp(2, 4596373779694328218LL, 4611686018427387904LL)), 4596373779694328218LL), 0LL);
                                    __VERIFIER_assume_implied((((-32LL) * rw88) + (32LL * ri103)), (-47LL));
                                    __VERIFIER_assume_implied(((32LL * rw88) + ((-32LL) * ri103)), 81LL);
                                    c_side = 1LL;
                                    c_qty = 1LL;
                                    c_px = ri103;
                                    c_rej = 0LL;
                                    if ((0LL < c_qty)) {
                                        if ((c_rej != 0LL)) {
                                            g_nrej = (g_nrej + 1LL);
                                        } else {
                                            if ((c_side == 0LL)) {
                                                ag_n0 = (ag_n0 + 1LL);
                                            } else {
                                                ag_n1 = (ag_n1 + 1LL);
                                            }
                                            if ((c_side == 0LL)) {
                                                g_oq0 = (g_oq0 + c_qty);
                                            } else {
                                                g_oq1 = (g_oq1 + c_qty);
                                            }
                                            g_nopen = (g_nopen + 1LL);
                                            if (0LL) {
                                                ok2 = 0LL;
                                            }
                                        }
                                    }
                                    u__orders_count = (u__orders_count + 1LL);
                                    u__last_entry_time = l_v_now_1_86;
                                }
                            }
                        }
                    }
                }
            }
        }
        __VERIFIER_assume((g_bid < g_ask));
        g_stepped = 1LL;
    }
    return 0;
}
