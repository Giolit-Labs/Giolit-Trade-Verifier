// WonderTrader's dual-thrust CTA strategy, verified from its C++ source: its target position.
spec WonderTraderDualThrust;

units { price = tick(0.2 INR); money = paise; }
ranges { price 15000 .. 25000; order_qty 1 .. 100; }
signals {
    hh: real in [3000.0, 5000.0];        // the highest high of the window
    ll: real in [3000.0, 5000.0];        // the lowest low
    hc: real in [3000.0, 5000.0];        // the highest close
    lc: real in [3000.0, 5000.0];        // the lowest close
    cur_px: real in [3000.0, 5000.0];    // the last close
    bar_open: real in [3000.0, 5000.0];  // the last bar's open
}

import "dualthrust.gbind";

constraints {
    within_lots:      always cta_pos <= 2 and cta_pos >= -2;
    reverse_via_flat: always not (prev(cta_pos) > 0 and cta_pos < 0) and not (prev(cta_pos) < 0 and cta_pos > 0);
}
