// The ladder quoter, verified from its C++ code: the loop that sends the levels is unrolled (levels = 3).
spec LadderImported;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; }
assumptions { market.bid < market.ask; }

import "ladder.gbind";

constraints {
    ladder_size:  always open_orders <= levels;
    exposure:     always open_qty(buy) <= levels * lot;
    counted:      always working == open_orders;
    passive:      always on new_order: order.price <= market.bid;
}
