// A ladder quoter: when flat and idle it rests `levels` buy orders of `lot` shares, one tick apart below the bid.
#pragma once

struct Tick { double bid, ask; };
struct Trade { long qty; bool orderDone; };

class Ladder {
public:
    void onTick(const Tick& t);
    void onTrade(const Trade& tr);
    void onReject();

private:
    void sendBuy(long qty, double price);   // the gateway (bound as the action)
    int levels = 3;
    long lot = 10;
    double tick = 0.05;
    int working = 0;        // the orders of the ladder still working
    long filled = 0;
};
