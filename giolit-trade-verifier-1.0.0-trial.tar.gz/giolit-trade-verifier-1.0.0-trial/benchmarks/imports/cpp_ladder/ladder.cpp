// The ladder: one loop sends every level.
#include "ladder.hpp"

void Ladder::onTick(const Tick& t) {
    if (working > 0) return;
    for (int i = 0; i < levels; ++i) {
        sendBuy(lot, t.bid - tick * i);
        working += 1;
    }
}

void Ladder::onTrade(const Trade& tr) {
    filled += tr.qty;
    if (tr.orderDone) working -= 1;
}

void Ladder::onReject() { working -= 1; }
