// WonderTrader's TWAP execution unit, verified from its C++ source: one parent target from flat.
spec WonderTraderTwap;

units { price = tick(0.2 INR); money = paise; }
ranges { price 15000 .. 25000; order_qty 1 .. 100; }
signals {
    parent: int in [-20, 20];          // the target position the upstream sets at the start
    stale_orders: bool;                // the order monitor finds orders past ord_sticky
    tick_time: int in [93000000, 103000000];
}
assumptions { market.bid < market.ask; }

import "twap.gbind";

constraints {
    never_past_target: always (_target_pos >= 0.0 and position >= 0 and real(position) <= _target_pos)
                           or (_target_pos < 0.0 and position <= 0 and real(position) >= _target_pos);
}
