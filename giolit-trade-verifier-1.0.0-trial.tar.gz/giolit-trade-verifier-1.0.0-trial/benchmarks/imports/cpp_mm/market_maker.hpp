// A market maker as typically written in C++: quotes both sides around the book, shaded by its inventory, which it
// tracks itself from its fills.
#pragma once
#include <algorithm>

struct Tick { double bid, ask; };                                // INR
struct Trade { long qty; double price; bool isBuy; };

class MarketMaker {
public:
    long lot = 100;                  // shares per quote
    long maxInventory = 500;         // long or short
    double skewPerShare = 0.001;     // INR the quotes move per share held
    double tick = 0.05;              // INR

    long inventory = 0;              // shares held (its own count)
    bool killed = false;
    double lastMid = 0.0;            // INR

    void onTick(const Tick& t);
    void onTrade(const Trade& tr);
    void onKill();

    double skew() const { return inventory * skewPerShare; }
    long openBuyQty() const;         // the order manager's view (elsewhere)
    long openSellQty() const;
    void sendBuy(long qty, double price);
    void sendSell(long qty, double price);
    void cancelAll();
};
