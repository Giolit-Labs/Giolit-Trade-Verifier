// The market maker, verified from its C++ code (market_maker.cpp).
spec MarketMakerImported;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; }
assumptions { market.bid < market.ask; }

import "mm.gbind";

constraints {
    inventory_long:  always position <= maxInventory;
    inventory_short: always position >= -maxInventory;
    own_count:       always inventory == position;
    passive_bid:     always on new_order where order.side == buy: order.price < market.ask;
    passive_ask:     always on new_order where order.side == sell: order.price > market.bid;
    quote_size:      always on new_order: order.qty <= lot;
    kill_stops:      after kill_switch: never new_order;
}
