// Fixed: the inventory check counts the quotes still working, and the quotes are clamped one tick inside the market.
#include "market_maker.hpp"

void MarketMaker::onTick(const Tick& t) {
    if (killed) return;
    lastMid = (t.bid + t.ask) / 2;
    cancelAll();
    if (inventory + openBuyQty() + lot <= maxInventory) sendBuy(lot, std::min(t.bid - skew(), t.ask - tick));
    if (inventory - openSellQty() - lot >= -maxInventory) sendSell(lot, std::max(t.ask - skew(), t.bid + tick));
}

void MarketMaker::onTrade(const Trade& tr) { inventory += tr.isBuy ? tr.qty : -tr.qty; }

void MarketMaker::onKill() {
    killed = true;
    cancelAll();
}
