// Two bugs:
//   * the inventory check ignores the quotes still working: cancels are not instant, so new quotes go out while old
//     ones can still fill, and the inventory overshoots its limit;
//   * a large short inventory shades the bid above the ask: the "passive" quote crosses the market.
#include "market_maker.hpp"

void MarketMaker::onTick(const Tick& t) {
    if (killed) return;
    lastMid = (t.bid + t.ask) / 2;
    cancelAll();
    if (inventory + lot <= maxInventory) sendBuy(lot, t.bid - skew());
    if (inventory - lot >= -maxInventory) sendSell(lot, t.ask - skew());
}

void MarketMaker::onTrade(const Trade& tr) { inventory += tr.isBuy ? tr.qty : -tr.qty; }

void MarketMaker::onKill() {
    killed = true;
    cancelAll();
}
