// Hummingbot's simple PMM, verified from its Python source: quotes around the mid, refreshed every 15 s.
spec HummingbotSimplePMM;

units { time = 1ms; price = tick(0.01 USD); money = cents; }   // the pair is quoted in USDT
ranges { price 200000 .. 400000; order_qty 1 .. 100; }
assumptions { market.bid < market.ask; }

import "simple_pmm.gbind";

constraints {
    // the script cancels and re-quotes in one tick without waiting for the cancels: does a side ever hold two quotes?
    one_quote_per_side: always open_qty(buy) <= 1 and open_qty(sell) <= 1;   // one lot per quote
    quote_size:         always on new_order: order.qty == 1;
    passive_bid:        always on new_order where order.side == buy: order.price < market.ask;
}
