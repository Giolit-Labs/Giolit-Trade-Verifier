// An accumulation strategy as typically written in Java: buy a target quantity in clips at the bid, one clip at a
// time. Fixed: only a fill that completes the order frees the strategy.
public class ClipBuyer {
    public interface Gateway { void sendBuy(long qty, double price); }
    public interface Logger { void info(String what); }
    public static final class Tick { public double bid, ask; }
    public static final class Trade { public long qty; public boolean orderDone; }

    private final Gateway gateway;
    private final Logger logger;
    private long target = 1000;     // shares to buy in all
    private long clip = 100;        // shares per order
    private long filled = 0;        // shares bought so far
    private boolean working;        // an order of ours is at the exchange

    public ClipBuyer(Gateway gateway, Logger logger) {
        this.gateway = gateway;
        this.logger = logger;
    }

    public void onTick(Tick tick) {
        if (working || filled >= target) return;
        long qty = Math.min(clip, target - filled);
        logger.info("sending a clip");
        gateway.sendBuy(qty, tick.bid);
        working = true;
    }

    public void onTrade(Trade trade) {
        filled += trade.qty;
        if (trade.orderDone) working = false;
    }

    public void onReject() { working = false; }
}
