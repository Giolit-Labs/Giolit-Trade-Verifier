"""An accumulation strategy as typically written in Python: buy a target quantity in clips at the bid, one clip at a
time. Fixed: only a fill that completes the order frees the strategy."""


class ClipBuyer:
    def __init__(self, gateway, logger):
        self.gateway = gateway      # the order gateway (bound as the action)
        self.logger = logger
        self.target = 1000          # shares to buy in all
        self.clip = 100             # shares per order
        self.filled = 0             # shares bought so far
        self.working = False        # an order of ours is at the exchange

    def on_tick(self, tick):
        if self.working or self.filled >= self.target:
            return
        qty = min(self.clip, self.target - self.filled)
        self.logger.info("sending a clip")
        self.gateway.send_buy(qty, tick.bid)
        self.working = True

    def on_trade(self, trade):
        self.filled += trade.qty
        if trade.order_done:
            self.working = False

    def on_reject(self):
        self.working = False
