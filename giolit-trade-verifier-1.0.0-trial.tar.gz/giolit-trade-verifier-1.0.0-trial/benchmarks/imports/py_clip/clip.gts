// The clip buyer, verified from its Python code (clip_buyer.py): rules, state and parameters come from the code.
spec ClipBuyerPython;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; }
assumptions { market.bid < market.ask; }

import "clip.gbind";

constraints {
    never_over:   always bought <= target;
    clip_size:    always on new_order: order.qty <= clip;
    one_working:  always open_orders <= 1;
    bookkeeping:  always filled == bought;
    buys_only:    always sold == 0;
}
