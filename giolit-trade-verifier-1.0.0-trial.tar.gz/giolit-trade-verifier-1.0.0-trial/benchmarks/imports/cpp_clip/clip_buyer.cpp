// The bug: any fill frees the strategy, also a partial one -- the next clip is sent while the rest of the last one is
// still working, and the target is overshot.
#include "clip_buyer.hpp"

void ClipBuyer::onTick(const Tick& t) {
    if (working || filled >= target) return;
    long qty = std::min(clip, target - filled);
    log("sending a clip");
    sendBuy(qty, t.bid);
    working = true;
}

void ClipBuyer::onTrade(const Trade& tr) {
    filled += tr.qty;
    working = false;
}

void ClipBuyer::onReject() { working = false; }
