// The clip buyer, verified from its C++ code (clip_buyer_fixed.cpp): rules, state and parameters come from the code.
spec ClipBuyerImported_fixed;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; }
assumptions { market.bid < market.ask; }

import "clip_fixed.gbind";

constraints {
    never_over:   always bought <= target;
    clip_size:    always on new_order: order.qty <= clip;
    one_working:  always open_orders <= 1;
    bookkeeping:  always filled == bought;
    buys_only:    always sold == 0;
}
