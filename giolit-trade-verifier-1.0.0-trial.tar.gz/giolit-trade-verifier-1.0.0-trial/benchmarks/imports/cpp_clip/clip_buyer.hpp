// An accumulation strategy as typically written in C++: buy a target quantity in clips at the bid, one clip at a time.
#pragma once
#include <algorithm>

struct Tick { double bid, ask, last; };                          // INR
struct Trade { long qty; double price; bool isBuy; bool orderDone; };

class ClipBuyer {
public:
    long target = 1000;    // shares to buy in all
    long clip = 100;       // shares per order
    long filled = 0;       // shares bought so far
    bool working = false;  // an order of ours is at the exchange

    void onTick(const Tick& t);
    void onTrade(const Trade& tr);
    void onReject();

    void sendBuy(long qty, double price);   // the order gateway (elsewhere)
    void log(const char* what);
};
