// Fixed: only a fill that completes the order frees the strategy.
#include "clip_buyer.hpp"

void ClipBuyer::onTick(const Tick& t) {
    if (working || filled >= target) return;
    long qty = std::min(clip, target - filled);
    log("sending a clip");
    sendBuy(qty, t.bid);
    working = true;
}

void ClipBuyer::onTrade(const Trade& tr) {
    filled += tr.qty;
    if (tr.orderDone) working = false;
}

void ClipBuyer::onReject() { working = false; }
