// The risk layer fixed: a market order is valued at the opposite quote, and the short check counts the working sells.
#include "pretrade_risk.hpp"

static bool sizeOk(long qty, long limit) { return qty > 0 && qty <= limit; }

bool PreTradeRisk::allow(const OrderRequest& o, const AccountState& a) const {
    if (a.killSwitch) return false;
    if (!sizeOk(o.qty, maxOrderQty)) return false;
    double px = o.isMarket ? (o.isBuy ? a.ask : a.bid) : o.price;
    if (o.qty * px > maxOrderValue) return false;
    long worstLong = a.position + a.openBuyQty + o.qty;
    long worstShort = a.position - a.openSellQty - o.qty;
    if (o.isBuy && worstLong > maxLong) return false;
    if (!o.isBuy && worstShort < -maxShort) return false;
    return true;
}
