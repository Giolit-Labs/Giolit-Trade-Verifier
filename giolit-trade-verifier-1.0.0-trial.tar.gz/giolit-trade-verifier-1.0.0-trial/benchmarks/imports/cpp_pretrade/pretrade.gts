// The broker's pre-trade checks, verified from the C++ code itself (pretrade_risk.cpp) for any strategy.
spec PreTradeImported;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 100000; }
mode controls_only;

import "pretrade.gbind";

constraints {
    order_size:  always on new_order: order.qty <= maxOrderQty;
    order_value: always on new_order: notional(order) <= 500000 INR;
    long_limit:  always position <= maxLong;
    short_limit: always position >= -maxShort;
    kill_stops:  after kill_switch: never new_order;
}
