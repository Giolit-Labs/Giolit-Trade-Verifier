// A broker's pre-trade risk layer, as typically written in C++: plain structs for the order and the account, and a
// check that every outgoing order must pass.
#pragma once
#include <algorithm>

struct OrderRequest {
    long qty;          // shares
    double price;      // INR; 0 for a market order
    bool isBuy;
    bool isMarket;
};

struct AccountState {
    long position;     // shares, long > 0
    long openBuyQty;   // leaves of the working buy orders
    long openSellQty;  // leaves of the working sell orders
    double bid, ask;   // INR
    bool killSwitch;
};

class PreTradeRisk {
public:
    long maxOrderQty = 500;
    double maxOrderValue = 500000.0;    // INR
    long maxLong = 2000;
    long maxShort = 1000;

    bool allow(const OrderRequest& o, const AccountState& a) const;
};
