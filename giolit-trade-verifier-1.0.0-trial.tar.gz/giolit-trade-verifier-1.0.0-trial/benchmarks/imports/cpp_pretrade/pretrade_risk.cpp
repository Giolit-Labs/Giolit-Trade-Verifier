// The risk layer with two bugs a reviewer easily misses:
//   * the value check skips market orders (their price field is 0), so a market order of any value passes;
//   * the short check forgets the sells still working, so several sells together can breach the short limit.
#include "pretrade_risk.hpp"

static bool sizeOk(long qty, long limit) { return qty > 0 && qty <= limit; }

bool PreTradeRisk::allow(const OrderRequest& o, const AccountState& a) const {
    if (a.killSwitch) return false;
    if (!sizeOk(o.qty, maxOrderQty)) return false;
    if (!o.isMarket && o.qty * o.price > maxOrderValue) return false;
    if (o.isBuy) {
        if (a.position + a.openBuyQty + o.qty > maxLong) return false;
    } else {
        if (a.position - o.qty < -maxShort) return false;
    }
    return true;
}
