# A C++ pre-trade risk layer, verified from its source

- `pretrade_risk.hpp` -- the order and account structs and the risk class (limits as members with initial values)
- `pretrade_risk.cpp` -- the check, with two bugs: market orders skip the value check; the short check forgets the
  working sells
- `pretrade_risk_fixed.cpp` -- both fixed
- `pretrade.gbind`, `pretrade_fixed.gbind` -- what the code means: which function is the check, which field is which
  concept, the price unit
- `pretrade.gts`, `pretrade_fixed.gts` -- the broker's constraints, for any strategy (controls-only), importing the code

```
trade-verify pretrade.gts --import-only     # the GTSL generated from the C++ code
trade-verify pretrade.gts                   # order_value and short_limit VIOLATED, the rest PROVEN
trade-verify pretrade_fixed.gts             # the fixes proved (order_value: see importer_design.md, known limits)
```
