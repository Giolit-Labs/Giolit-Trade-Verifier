// TEMPLATE smart_order_router -- one parent order across several venues, no overfill
// Sweep every venue's book for the quantity still to buy, never more in total than the parent; the kill switch
// stops every venue.
//
// Adapt: the venues; target and clip; the routing rule (here: split across both venues at their asks); the
// assumptions that tie the venues' books together.
//
// Standard constraints of the family:
//   no_overfill          the parent is never overfilled, though fills of different venues race each other
//   venue_exposure       the open quantity at each venue stays within its cap
//   no_order_after_kill  after the kill switch, no new order on any venue
//   kill_stops_all       after the kill switch every order is cancelling or done (may stay UNDECIDED: a per-order
//                        invariant over the order states)
spec SmartOrderRouterTemplate;

units { price = tick(0.05 INR); money = paise; }
venues { NSE; BSE; }
ranges { price 20000 .. 40000; order_qty 1 .. 500; }
assumptions {
    market.bid < market.ask;
    market[NSE].ask within 20 ticks of market[BSE].ask;
}

strategy SweepRouter {
    parameters { target = 150; clip = 100; }
    state { remaining: qty = 150; }
    rules {
        on market_update when not kill_switch and remaining > 0 and open_qty(buy) == 0 {
            buy(min(remaining, clip), limit = market[NSE].ask, venue = NSE);
            buy(min(remaining, clip), limit = market[BSE].ask, venue = BSE);
        }
        on fill(o) { remaining -= o.last_qty; }
        on kill_switch { cancel_all(); }
        on cancel_reject(o) when kill_switch { cancel(o); }
    }
}

risk_controls {
    clip:      reject when order.qty > clip;
    venue_cap: reject when open_qty(buy, order.venue) + order.qty > clip;
    parent:    reject when order.side == buy and bought + open_qty(buy) + order.qty > target;
    kill:      reject when kill_switch;
}

constraints {
    no_overfill:         always bought <= target;
    venue_exposure:      always open_qty(buy, NSE) <= clip and open_qty(buy, BSE) <= clip;
    no_order_after_kill: after kill_switch: never new_order;
    kill_stops_all:      for each order o: after kill_switch: always not (live(o) and not pending_cancel(o));
}
