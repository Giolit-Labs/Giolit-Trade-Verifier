// TEMPLATE pairs -- a two-leg spread trade with legging and exposure limits
// When the spread signal is high, sell one symbol and buy the other in the hedge ratio, as one order of two legs
// (both pass the risk controls, or neither is sent).
//
// Adapt: the symbols and their price ranges and betas; the hedge ratio (here 3 x A against 2 x B: clip = 100 A,
// hedge = 150 B); the signal (your model's z-score, any value in its range); max_pairs; the exposure limit.
//
// Standard constraints of the family:
//   pair_imbalance   the legs never drift apart by more than one pair (legging risk: a rejected or unfilled leg)
//   short_cap        the short leg stays within max_pairs clips
//   long_cap         the long leg stays within max_pairs hedges
//   gross_checked    every order passes the gross exposure limit
//   beta_neutral     the beta-weighted exposure stays within its limit
spec PairsTemplate;

units { price = tick(0.05 INR); money = paise; }
symbols {
    A price 30000 .. 34000 beta 1.0;
    B price 18000 .. 22000 beta 1.2;
}
ranges { order_qty 1 .. 1000; }
assumptions { market.bid < market.ask; }
signals { zscore: int in [-400, 400]; }        // the spread's z-score x 100, from your model

strategy Pairs {
    parameters { clip = 100; hedge = 150; entry = 200; max_pairs = 5; }
    state { pairs: int = 0; }
    rules {
        // a new pair only from balanced positions, with nothing working
        on market_update when zscore > entry and pairs < max_pairs and open_orders(A) == 0 and open_orders(B) == 0
                          and 3 * position[A] + 2 * position[B] == 0 {
            legs {
                sell(clip, limit = market[A].bid, symbol = A);
                buy(hedge, limit = market[B].ask, symbol = B);
            }
            pairs += 1;
        }
    }
}

risk_controls {
    leg_size: reject when order.qty > hedge;
    gross:    reject when gross_exposure + notional(order) > 4000000 INR;
}

constraints {
    pair_imbalance: always abs(3 * position[A] + 2 * position[B]) <= 300;
    short_cap:      always position[A] >= -(max_pairs * clip);
    long_cap:       always position[B] <= max_pairs * hedge;
    gross_checked:  always on new_order: gross_exposure + notional(order) <= 4000000 INR;
    beta_neutral:   always beta_exposure <= 2000000 INR;
}
