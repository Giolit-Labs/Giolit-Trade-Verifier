// TEMPLATE delta_hedge -- keep an options book delta-neutral with the underlying
// The book's delta (in shares) comes from your pricer as a signal; whenever the net delta leaves the band, one
// hedge order brings it back towards zero.
//
// Adapt: the delta's range, band, clip and the hedge position limit; the limits (here: cross the spread).
//
// Standard constraints of the family:
//   reduces_risk    every hedge order reduces the net delta (sells when long delta, buys when short)
//   no_overshoot    no hedge order is larger than the net delta it corrects
//   hedge_long / hedge_short   the hedge position stays within its limit
//   hedge_size      every hedge order is at most one clip
spec DeltaHedgeTemplate;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; }
assumptions { market.bid < market.ask; }
signals { book_delta: int in [-2000, 2000]; }   // the options book's delta, from your pricer

strategy DeltaHedger {
    parameters { band = 100; clip = 200; max_hedge = 3000; }
    rules {
        on market_update when open_orders == 0 {
            let net = position + book_delta;
            if net > band and position - min(clip, net) >= -max_hedge {
                sell(min(clip, net), limit = market.bid);
            }
            if net < -band and position + min(clip, -net) <= max_hedge {
                buy(min(clip, -net), limit = market.ask);
            }
        }
    }
}

risk_controls {
    size:      reject when order.qty > clip;
    long_cap:  reject when order.side == buy and position + open_qty(buy) + order.qty > max_hedge;
    short_cap: reject when order.side == sell and position - open_qty(sell) - order.qty < -max_hedge;
}

constraints {
    reduces_risk: always on new_order: (order.side == sell) == (position + book_delta > 0);
    no_overshoot: always on new_order: order.qty <= abs(position + book_delta);
    hedge_long:   always position <= max_hedge;
    hedge_short:  always position >= -max_hedge;
    hedge_size:   always on new_order: order.qty <= clip;
}
