// TEMPLATE risk_gateway -- pre-trade risk controls certified for any strategy
// Controls-only mode: the checks a broker or exchange member runs on every order (SEC 15c3-5 erroneous-order and
// credit checks; SEBI algorithmic-trading order checks: quantity and value limits, price bands, position limits,
// kill switch).
//
// Adapt: the limits; the price band (here 5% around the last trade); whether market orders are allowed. The rules of
// the strategy are not used: at every step any order or cancel may be sent.
//
// Standard constraints of the family:
//   order_size     no order above the maximum quantity
//   order_value    no order above the maximum value (a market order valued at the opposite quote)
//   price_band     every limit order is priced within the band around the last trade
//   no_market      no market orders
//   long_limit / short_limit   the position stays within its limits, whatever is working
//   kill_stops     after the kill switch, no new order
//   accounting     position = bought - sold
spec RiskGatewayTemplate;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 100000; }
mode controls_only;

strategy Any {
    parameters {
        max_order_qty = 5000;
        max_order_value = 5000000 INR;
        max_long = 20000;
        max_short = 20000;
    }
}

risk_controls {
    size:      reject when order.qty > max_order_qty;
    value:     reject when notional(order) > max_order_value;
    band:      reject when not (order.price within 5% of market.last);
    market:    reject when order.is_market;
    long_cap:  reject when order.side == buy and position + open_qty(buy) + order.qty > max_long;
    short_cap: reject when order.side == sell and position - open_qty(sell) - order.qty < -max_short;
    kill:      reject when kill_switch;
}

constraints {
    order_size:  always on new_order: order.qty <= max_order_qty;
    order_value: always on new_order: notional(order) <= max_order_value;
    price_band:  always on new_order: order.price within 5% of market.last;
    no_market:   always on new_order: not order.is_market;
    long_limit:  always position <= max_long;
    short_limit: always position >= -max_short;
    kill_stops:  after kill_switch: never new_order;
    accounting:  always position == bought - sold;
}
