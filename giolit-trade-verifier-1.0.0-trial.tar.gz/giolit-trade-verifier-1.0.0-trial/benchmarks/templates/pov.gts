// TEMPLATE pov -- percentage of volume: buy as a fixed share of the traded volume
//
// Adapt: quantity, the rate (here 1 in 10: `10 * ... <= market.volume`), child_max; the limit; the ranges.
//
// Standard constraints of the family:
//   never_over     the parent is never overfilled
//   participation  bought + open is never more than the rate of the market's volume (own fills count as volume)
//   child_size     every child order is at most child_max
//   one_side       a buy algorithm never sells
spec PovTemplate;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; volume_step 0 .. 5000; }
assumptions { market.bid <= market.ask; }

strategy POV {
    parameters { quantity = 20000; child_max = 200; }
    rules {
        on market_update {
            let done = bought + open_qty(buy);
            if done + child_max <= quantity and 10 * (done + child_max) <= market.volume {
                buy(child_max, limit = market.bid);
            }
        }
    }
}

risk_controls {
    clip:   reject when order.qty > child_max;
    parent: reject when bought + open_qty(buy) + order.qty > quantity;
    rate:   reject when 10 * (bought + open_qty(buy) + order.qty) > market.volume;
}

constraints {
    never_over:    always bought <= quantity;
    participation: always 10 * (bought + open_qty(buy)) <= market.volume;
    child_size:    always on new_order: order.qty <= child_max;
    one_side:      always sold == 0;
}
