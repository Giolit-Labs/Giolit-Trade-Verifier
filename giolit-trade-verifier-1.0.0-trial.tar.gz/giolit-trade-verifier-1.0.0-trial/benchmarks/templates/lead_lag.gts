// TEMPLATE lead_lag -- trade a follower symbol when a leader symbol has moved
// The leader's last price against its value a few events ago (history), with a cap on the follower's position.
//
// Adapt: the symbols and ranges; the lag (events) and the move threshold; clip and max_position; the limits.
//
// Standard constraints of the family:
//   follower_only    the strategy never trades the leader
//   position_long / position_short   the follower's position stays within its cap
//   one_at_a_time    at most one order of the strategy works at a time
//   order_size       every order is at most one clip
spec LeadLagTemplate;

units { price = tick(0.05 INR); money = paise; }
symbols {
    LEADER   price 20000 .. 40000;
    FOLLOWER price 20000 .. 40000;
}
ranges { order_qty 1 .. 500; }
assumptions { market.bid < market.ask; }

strategy LeadLag {
    parameters { lag = 3; move = 20 ticks; clip = 50; max_position = 500; }
    rules {
        on market_update when event.symbol == LEADER and open_orders(FOLLOWER) == 0 {
            let up = market[LEADER].last - history(market[LEADER].last, lag);
            if up >= move and position[FOLLOWER] + clip <= max_position {
                buy(clip, limit = market[FOLLOWER].ask, symbol = FOLLOWER);
            }
            if up <= -move and position[FOLLOWER] - clip >= -max_position {
                sell(clip, limit = market[FOLLOWER].bid, symbol = FOLLOWER);
            }
        }
    }
}

risk_controls {
    size:     reject when order.qty > clip;
    long_cap: reject when order.side == buy and position + open_qty(buy) + order.qty > max_position;
    short_cap: reject when order.side == sell and position - open_qty(sell) - order.qty < -max_position;
}

constraints {
    follower_only:  always on new_order: order.symbol == FOLLOWER;
    position_long:  always position[FOLLOWER] <= max_position;
    position_short: always position[FOLLOWER] >= -max_position;
    one_at_a_time:  always open_orders <= 1;
    order_size:     always on new_order: order.qty <= clip;
}
