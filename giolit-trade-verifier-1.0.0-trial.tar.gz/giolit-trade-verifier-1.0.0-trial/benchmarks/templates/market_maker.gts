// TEMPLATE market_maker -- two-sided quoting with an inventory skew and inventory limits
// Quotes around the book, shaded by the inventory, never crossing the market.
//
// Adapt: the symbol, units and ranges; lot, max_inventory and skew; the quote prices (here: join the best bid and ask,
// shaded by the inventory, never crossing). Keep the risk controls and the standard constraints; add your own.
//
// Standard constraints of the family:
//   inventory_long / inventory_short  the inventory stays within its limit (any number of quotes, any fills)
//   passive_bid / passive_ask         quotes never cross the market (no aggressive fills from a quoting bug)
//   quote_size                        every quote is at most one lot
//   limit_orders_only                 a market maker never sends market orders
//   kill_stops                        after the kill switch, no new order
spec MarketMakerTemplate;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; }
assumptions { market.bid < market.ask; }

strategy MarketMaker {
    parameters {
        lot = 100 shares;
        max_inventory = 1000;
        skew = 1 ticks;          // the quotes move down by `skew` per lot held (up per lot short)
    }
    rules {
        on market_update when not kill_switch {
            cancel_all();
            let shade = position / lot * skew;
            if position + open_qty(buy) + lot <= max_inventory {
                buy(lot, limit = min(market.bid - shade, market.ask - 1 ticks));
            }
            if position - open_qty(sell) - lot >= -max_inventory {
                sell(lot, limit = max(market.ask - shade, market.bid + 1 ticks));
            }
        }
        on kill_switch { cancel_all(); }
    }
}

risk_controls {
    size:       reject when order.qty > lot;
    long_cap:   reject when order.side == buy and position + open_qty(buy) + order.qty > max_inventory;
    short_cap:  reject when order.side == sell and position - open_qty(sell) - order.qty < -max_inventory;
    kill:       reject when kill_switch;
}

constraints {
    inventory_long:    always position <= max_inventory;
    inventory_short:   always position >= -max_inventory;
    passive_bid:       always on new_order where order.side == buy: order.price < market.ask;
    passive_ask:       always on new_order where order.side == sell: order.price > market.bid;
    quote_size:        always on new_order: order.qty <= lot;
    limit_orders_only: always on new_order: not order.is_market;
    kill_stops:        after kill_switch: never new_order;
}
