// TEMPLATE vwap -- a parent buy order worked along the market's traded volume
// The target grows with the volume the market has traded, against the volume expected for the day.
//
// Adapt: quantity, expected_volume (the day's volume forecast), child_max; the limit; the ranges.
//
// Standard constraints of the family:
//   never_over       the parent is never overfilled
//   on_curve         bought + open never runs ahead of the parent
//   volume_tracking  bought + open never exceeds the target the market's volume gives (plus one child)
//   child_size       every child order is at most child_max
//   one_side         a buy algorithm never sells
spec VwapTemplate;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 1000; volume_step 0 .. 5000; }
assumptions { market.bid <= market.ask; }

strategy VWAP {
    parameters {
        quantity = 10000;
        expected_volume = 500000;
        child_max = 500;
    }
    rules {
        on market_update {
            // the curve: quantity * volume / expected_volume, written without division
            let done = bought + open_qty(buy);
            if done + child_max <= quantity and expected_volume * (done + child_max) <= quantity * market.volume {
                buy(child_max, limit = market.bid);
            }
        }
    }
}

risk_controls {
    clip:   reject when order.qty > child_max;
    parent: reject when bought + open_qty(buy) + order.qty > quantity;
}

constraints {
    never_over:      always bought <= quantity;
    on_curve:        always bought + open_qty(buy) <= quantity;
    volume_tracking: always expected_volume * (bought + open_qty(buy)) <= quantity * market.volume;
    child_size:      always on new_order: order.qty <= child_max;
    one_side:        always sold == 0;
}
