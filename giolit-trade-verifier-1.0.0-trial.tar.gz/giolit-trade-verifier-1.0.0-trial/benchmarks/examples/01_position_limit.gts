// The example from the problem statement: the risk check looks at the position only, not at the
// orders still open, so two orders of 100 each from a position of 900 end at 1100.
spec PositionLimit;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 500; }

strategy Accumulate {
    parameters {
        initial_position = 900;
        max_position = 1000;
    }
    rules {
        on market_update {
            buy(100, limit = market.bid);
        }
    }
}

risk_controls {
    position_cap: reject when position + order.qty > max_position;
}

constraints {
    position_limit: always position <= max_position;
}
