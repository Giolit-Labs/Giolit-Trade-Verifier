// What can be guaranteed about profit, and what cannot.
//
// A market maker buys a lot at a fixed bid level and offers what it bought at a fixed ask level two ticks higher; it
// holds at most 500 shares. Against ANY market (prices anywhere in the range, fills of any size at any time, rejects,
// cancels in any order):
//   * edge_locked_in   -- PROVEN: every share sold earned at least the spread, whatever prices the fills had;
//   * worst_case_loss  -- PROVEN: even if the price collapses to the bottom of the range, the loss on the inventory is
//                         at most 500 x (bid level - lowest price);
//   * never_loses      -- VIOLATED: marked to the market, the strategy can be under water (it bought, then the market
//                         fell). No strategy that holds inventory can be proved profitable against every market.
spec GridMarketMaker;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 500; }
assumptions { market.bid < market.ask; }

strategy Grid {
    parameters {
        bid_level = 29990 ticks;    // 1499.50 INR
        ask_level = 29992 ticks;    // 1499.60 INR: two ticks of edge
        lot = 100;
        max_inventory = 500;
        max_loss = 249750.00 INR;   // 500 shares x (1499.50 - 1000.00 INR, the lowest price of the range)
    }
    rules {
        on market_update when open_qty(buy) == 0 and position + lot <= max_inventory {
            buy(lot, limit = bid_level);
        }
        on fill(o) when o.side == buy {
            sell(o.last_qty, limit = ask_level);
        }
    }
}

risk_controls {
    inventory: reject when order.side == buy and position + open_qty(buy) + order.qty > max_inventory;
}

constraints {
    inventory_limit: always position <= max_inventory;
    edge_locked_in:  always cash + position * bid_level >= sold * (ask_level - bid_level);
    worst_case_loss: always cash + position * 20000 ticks >= -max_loss;
    never_loses:     always cash + position * market.bid >= 0;
}
