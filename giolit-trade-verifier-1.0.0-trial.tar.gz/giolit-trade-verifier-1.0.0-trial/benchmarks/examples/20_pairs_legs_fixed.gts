// The pairs trade of 19_pairs_legs.gts, fixed: a new pair opens only when the positions are balanced (a half-done pair
// first has to be completed or unwound), so at most one pair is ever unhedged.
spec PairsTradeFixed;

units { price = tick(0.05 INR); money = paise; }
symbols {
    HDFCBANK  price 30000 .. 34000 beta 1.0;    // 1500 .. 1700 INR
    ICICIBANK price 18000 .. 22000 beta 1.2;    //  900 .. 1100 INR
}
ranges { order_qty 1 .. 1000; }
assumptions { market.bid < market.ask; }
signals { zscore: int in [-400, 400]; }        // the spread's z-score x 100

strategy Pairs {
    parameters { clip = 100; hedge = 150; entry = 200; max_pairs = 5; }
    state { pairs: int = 0; }
    rules {
        on market_update when zscore > entry and pairs < max_pairs and open_orders(HDFCBANK) == 0 and open_orders(ICICIBANK) == 0
                          and market[HDFCBANK].last >= history(market[HDFCBANK].last, 3)
                          and 3 * position[HDFCBANK] + 2 * position[ICICIBANK] == 0 {
            legs {
                sell(clip, limit = market[HDFCBANK].bid, symbol = HDFCBANK);
                buy(hedge, limit = market[ICICIBANK].ask, symbol = ICICIBANK);
            }
            pairs += 1;
        }
    }
}

risk_controls {
    leg_size: reject when order.qty > hedge;
    gross:    reject when gross_exposure + notional(order) > 4000000 INR;
}

constraints {
    pair_imbalance:  always abs(3 * position[HDFCBANK] + 2 * position[ICICIBANK]) <= 300;
    hdfc_short_cap:  always position[HDFCBANK] >= -(max_pairs * clip);
    gross_checked:   always on new_order: gross_exposure + notional(order) <= 4000000 INR;
    beta_hedged:     always beta_exposure <= 2000000 INR;
}
