// The same strategy with a kill-switch risk control: no order can leave after the kill switch.
spec KillSwitchFixed;

ranges { price 100 .. 200; order_qty 1 .. 1000; }

strategy Reload {
    parameters { clip = 50; }
    rules {
        on market_update when not kill_switch {
            buy(clip, limit = market.bid);
        }
        on fill(o) {
            buy(o.last_qty, limit = market.bid);
        }
        on kill_switch {
            cancel_all();
        }
    }
}

risk_controls {
    kill: reject when kill_switch;
}

constraints {
    no_order_after_kill: after kill_switch: never new_order;
    filled_within_order: for each order o: always o.cum_qty <= o.qty;
}
