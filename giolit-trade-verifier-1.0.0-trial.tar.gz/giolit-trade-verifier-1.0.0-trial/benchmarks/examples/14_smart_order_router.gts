// A smart order router working one parent buy order across two venues (NSE and BSE). On every market update it sweeps
// both books for the quantity still to buy, and the kill switch cancels the working orders.
//
// Two concurrency bugs that a single-venue test never shows:
//   * no_overfill   -- both venues fill the same remaining quantity before either fill is seen: the parent overfills;
//   * kill_stops_all -- the kill switch cancels NSE only: the BSE order keeps working after the kill.
// See 15_smart_order_router_fixed.gts for the fix.
spec SmartOrderRouter;

units { price = tick(0.05 INR); money = paise; }
venues { NSE; BSE; }
ranges { price 20000 .. 40000; order_qty 1 .. 500; }
assumptions {
    market.bid < market.ask;                  // every venue's book
    market[NSE].ask within 20 ticks of market[BSE].ask;
}

strategy SweepRouter {
    parameters { target = 150; clip = 100; }
    state { remaining: qty = 150; }
    rules {
        on market_update when not kill_switch and remaining > 0 and open_qty(buy) == 0 {
            buy(min(remaining, clip), limit = market[NSE].ask, venue = NSE);
            buy(min(remaining, clip), limit = market[BSE].ask, venue = BSE);
        }
        on fill(o) { remaining -= o.last_qty; }
        on kill_switch { cancel_all(NSE); }
    }
}

risk_controls {
    clip:      reject when order.qty > clip;
    venue_cap: reject when open_qty(buy, order.venue) + order.qty > clip;
}

constraints {
    no_overfill:         always bought <= target;
    venue_exposure:      always open_qty(buy, NSE) <= clip and open_qty(buy, BSE) <= clip;
    no_order_after_kill: after kill_switch: never new_order;
    kill_stops_all:      for each order o: after kill_switch: always not (live(o) and not pending_cancel(o));
}
