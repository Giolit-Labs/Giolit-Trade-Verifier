// Optimization (trade-verify --optimize): the implementation shortfall of buying 1000 shares in two child orders,
// against any market within the price range. The best and the worst cost are each shown as a value a run reaches
// and a bound proved for every run: here the extremes are buying everything at the lowest and at the highest price
// the range allows (1000 shares x 1000 ticks x 5 paise = 5,000,000 paise either way).
spec ExecutionCost;

units { price = tick(0.05 INR); money = paise; }
ranges { price 29000 .. 31000; order_qty 1 .. 1000; }

strategy Child {
    parameters {
        quantity = 1000;
        child = 500;
        arrival_price = 1500.00 INR;
    }
    rules {
        on market_update when bought + open_qty(buy) < quantity {
            buy(min(child, quantity - bought - open_qty(buy)), limit = market.ask);
        }
    }
}

constraints {
    never_over: always bought <= quantity;
}

objective {
    minimize implementation_shortfall;
}
