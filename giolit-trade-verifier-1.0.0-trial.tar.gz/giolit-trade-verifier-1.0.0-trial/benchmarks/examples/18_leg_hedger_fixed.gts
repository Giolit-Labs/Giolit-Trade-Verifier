// The leg hedger of 17_leg_hedger.gts, fixed: a new INFY clip starts only when the hedges of the last one are done, so
// at most one clip is ever unhedged (the INFY clip still working plus the TCS hedges still working).
spec LegHedgerFixed;

units { price = tick(0.05 INR); money = paise; }
symbols {
    INFY price 28000 .. 32000;     // 1400 .. 1600 INR
    TCS  price 68000 .. 72000;     // 3400 .. 3600 INR
}
ranges { order_qty 1 .. 500; }
assumptions { market.bid < market.ask; }

strategy Hedger {
    parameters { clip = 100; max_long = 1000; }
    rules {
        on market_update when event.symbol == INFY and open_qty(buy, INFY) == 0 and open_qty(sell, TCS) == 0 and position[INFY] + clip <= max_long {
            buy(clip, limit = market[INFY].bid, symbol = INFY);
        }
        on fill(o) when o.symbol == INFY { sell(o.last_qty, symbol = TCS); }
        on reject(o) when o.symbol == TCS { sell(o.leaves, symbol = TCS); }
    }
}

risk_controls {
    clip: reject when order.qty > clip;
}

constraints {
    unhedged:   always position[INFY] + position[TCS] <= clip;
    long_limit: always position[INFY] <= max_long;
    no_tcs_buy: always on new_order: order.symbol == TCS => order.side == sell;
}
