// The same desk controls with a gap: the position cap only looks at buy orders, so a strategy can
// sell its way past the short limit.
spec DeskControlsGap;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 10000; }
mode controls_only;

strategy Any {
    parameters { max_long = 1000; max_short = 1000; max_clip = 500; }
}

risk_controls {
    clip:      reject when order.qty > max_clip;
    long_cap:  reject when position + open_qty(buy) + order.qty > max_long;
}

constraints {
    long_limit:   always position <= max_long;
    short_limit:  always position >= -max_short;
}
