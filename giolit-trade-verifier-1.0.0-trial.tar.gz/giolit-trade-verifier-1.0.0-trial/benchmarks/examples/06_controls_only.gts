// Risk-control certification: the controls alone, against ANY strategy (mode controls_only). At every
// step the strategy may send any buy or sell order, limit or market, of any size, or cancel any order.
spec DeskControls;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 10000; }
mode controls_only;

market symbolic { symbol INFY; }

strategy Any {
    parameters { max_long = 1000; max_short = 1000; max_clip = 500; }
}

risk_controls {
    clip:      reject when order.qty > max_clip;
    long_cap:  reject when order.side == buy and position + open_qty(buy) + order.qty > max_long;
    short_cap: reject when order.side == sell and position - open_qty(sell) - order.qty < -max_short;
    kill:      reject when kill_switch;
}

constraints {
    long_limit:   always position <= max_long;
    short_limit:  always position >= -max_short;
    order_size:   always on new_order: order.qty <= max_clip;
    kill_stops:   after kill_switch: never new_order;
    accounting:   always position == bought - sold;
}
