// A hedged accumulation across two symbols: the strategy buys INFY in clips and sells the same quantity of TCS (the
// hedge, a market order) on every INFY fill; a rejected hedge is sent again.
//
// The bug: a new INFY clip may start while the hedges of the last one are still working, so the unhedged quantity
// (INFY bought but not yet sold as TCS) grows with every clip. A single-symbol test cannot see it. See
// 18_leg_hedger_fixed.gts for the fix.
spec LegHedger;

units { price = tick(0.05 INR); money = paise; }
symbols {
    INFY price 28000 .. 32000;     // 1400 .. 1600 INR
    TCS  price 68000 .. 72000;     // 3400 .. 3600 INR
}
ranges { order_qty 1 .. 500; }
assumptions { market.bid < market.ask; }

strategy Hedger {
    parameters { clip = 100; max_long = 1000; }
    rules {
        on market_update when event.symbol == INFY and open_qty(buy, INFY) == 0 and position[INFY] + clip <= max_long {
            buy(clip, limit = market[INFY].bid, symbol = INFY);
        }
        on fill(o) when o.symbol == INFY { sell(o.last_qty, symbol = TCS); }
        on reject(o) when o.symbol == TCS { sell(o.leaves, symbol = TCS); }
    }
}

risk_controls {
    clip: reject when order.qty > clip;
}

constraints {
    unhedged:   always position[INFY] + position[TCS] <= clip;
    long_limit: always position[INFY] <= max_long;
    no_tcs_buy: always on new_order: order.symbol == TCS => order.side == sell;
}
