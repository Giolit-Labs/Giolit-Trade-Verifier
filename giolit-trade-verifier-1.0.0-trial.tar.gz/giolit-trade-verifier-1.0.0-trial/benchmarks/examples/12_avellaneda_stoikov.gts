// The Avellaneda-Stoikov market maker (Avellaneda & Stoikov, "High-frequency trading in a limit order book",
// Quantitative Finance 2008), written as it runs in production C++: binary64 arithmetic, an EWMA estimate of the
// variance of mid-price changes (returns clipped by an outlier filter), a reservation price skewed against the
// inventory, the optimal spread, quotes rounded outward to whole ticks, and cancel-and-replace on every market update.
//
//   reservation  r     = mid - q * gamma * sigma2 * horizon
//   spread       delta = gamma * sigma2 * horizon + (2 / gamma) * ln(1 + gamma / kappa)
//   quotes             = floor(r - delta / 2), ceil(r + delta / 2)
//
// The bug: with a short inventory and a volatile market the reservation price rises above the ask, and the "passive"
// bid is a marketable order that crosses the spread (and the same for the ask when long). See 13_ for the fix.
spec AvellanedaStoikov;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 100; }

assumptions {
    market.bid < market.ask;
    market.ask - market.bid <= 10;
    on market_update: market.bid within 50 ticks of prev(market.bid);   // one update moves the market <= 50 ticks
}

strategy MarketMaker {
    parameters {
        gamma = 0.002;                       // risk aversion (per share, per tick^2)
        kappa = any real in [0.5, 3.0];      // order book liquidity (fitted online in production): any value
        lambda = 0.94;                       // EWMA decay (RiskMetrics)
        horizon = 1.0;                       // T - t, normalised
        max_move = 50.0;                     // outlier filter: mid changes are clipped to +-50 ticks
        clip = 10;
        max_inventory = 100;
    }
    state {
        sigma2: real in [0.0, 2600.0] = 4.0;           // variance of mid changes (ticks^2): at most max_move^2
        last_mid: real price in [0.0, 50000.0] = 0.0;
    }
    rules {
        on start {
            last_mid = real(market.bid + market.ask) / 2.0;
        }
        on market_update {
            let mid = real(market.bid + market.ask) / 2.0;
            let d = min(max(mid - last_mid, -max_move), max_move);
            sigma2 = lambda * sigma2 + (1.0 - lambda) * d * d;
            last_mid = mid;
            let q = real(max(-max_inventory, min(max_inventory, position)));
            let r = mid - q * gamma * sigma2 * horizon;
            let delta = gamma * sigma2 * horizon + 2.0 / gamma * ln(1.0 + gamma / kappa);
            cancel_all();
            if position < max_inventory { buy(clip, limit = floor(r - delta / 2.0)); }
            if position > -max_inventory { sell(clip, limit = ceil(r + delta / 2.0)); }
        }
    }
}

risk_controls {
    long_cap:  reject when order.side == buy and position + open_qty(buy) + order.qty > max_inventory + clip;
    short_cap: reject when order.side == sell and position - open_qty(sell) - order.qty < -(max_inventory + clip);
}

constraints {
    inventory_long:  always position <= max_inventory + clip;
    inventory_short: always position >= -(max_inventory + clip);
    passive_bid:     always on new_order where order.side == buy: order.price < market.ask;
    passive_ask:     always on new_order where order.side == sell: order.price > market.bid;
    quote_band:      always on new_order: order.price within 600 ticks of market.bid;
}
