// A moving average of the bid kept at the exact boundary of its range: ema never falls below the lowest price. True in
// binary64 too (a convex update stays between its operands); the provers get it from the convex-update accelerator.
spec EmaBoundary;
units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 100; }
assumptions { market.bid < market.ask; }
strategy Ema {
    parameters { alpha = 0.1; }
    state { ema: real price in [20000.0, 40000.0] = 30000.0; }
    rules { on market_update { ema = ema + alpha * (real(market.bid) - ema); } }
}
constraints {
    at_least_lowest: always ema >= 20000.0;
}
