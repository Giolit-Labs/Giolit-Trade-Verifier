// A pairs trade: when the research model's z-score of the HDFCBANK/ICICIBANK spread is high (a signal: any value in
// its range at every market update) and HDFCBANK is not falling, the strategy sells HDFCBANK and buys 1.5 times as
// many ICICIBANK shares as one order of two legs. Both legs pass the risk controls together.
//
// The bug: when the exchange rejects one leg after the other has filled, the pair is left half done -- and the next
// signal opens another pair, so the unhedged quantity grows pair by pair. See 20_pairs_legs_fixed.gts.
spec PairsTrade;

units { price = tick(0.05 INR); money = paise; }
symbols {
    HDFCBANK  price 30000 .. 34000 beta 1.0;    // 1500 .. 1700 INR
    ICICIBANK price 18000 .. 22000 beta 1.2;    //  900 .. 1100 INR
}
ranges { order_qty 1 .. 1000; }
assumptions { market.bid < market.ask; }
signals { zscore: int in [-400, 400]; }        // the spread's z-score x 100

strategy Pairs {
    parameters { clip = 100; hedge = 150; entry = 200; max_pairs = 5; }
    state { pairs: int = 0; }
    rules {
        on market_update when zscore > entry and pairs < max_pairs and open_orders(HDFCBANK) == 0 and open_orders(ICICIBANK) == 0
                          and market[HDFCBANK].last >= history(market[HDFCBANK].last, 3) {
            legs {
                sell(clip, limit = market[HDFCBANK].bid, symbol = HDFCBANK);
                buy(hedge, limit = market[ICICIBANK].ask, symbol = ICICIBANK);
            }
            pairs += 1;
        }
    }
}

risk_controls {
    leg_size: reject when order.qty > hedge;
    gross:    reject when gross_exposure + notional(order) > 4000000 INR;
}

constraints {
    pair_imbalance:  always abs(3 * position[HDFCBANK] + 2 * position[ICICIBANK]) <= 300;
    hdfc_short_cap:  always position[HDFCBANK] >= -(max_pairs * clip);
    gross_checked:   always on new_order: gross_exposure + notional(order) <= 4000000 INR;
    beta_hedged:     always beta_exposure <= 2000000 INR;
}
