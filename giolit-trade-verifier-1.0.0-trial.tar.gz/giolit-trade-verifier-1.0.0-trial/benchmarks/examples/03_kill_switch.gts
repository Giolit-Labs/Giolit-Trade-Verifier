// The kill switch stops the market-data rule, but the fill rule still re-enters the market:
// an order is sent after the kill switch is on (constraint C of the problem statement).
spec KillSwitch;

ranges { price 100 .. 200; order_qty 1 .. 1000; }

strategy Reload {
    parameters { clip = 50; }
    rules {
        on market_update when not kill_switch {
            buy(clip, limit = market.bid);
        }
        on fill(o) {
            // replace what was filled -- forgets to look at the kill switch
            buy(o.last_qty, limit = market.bid);
        }
        on kill_switch {
            cancel_all();
        }
    }
}

constraints {
    no_order_after_kill: after kill_switch: never new_order;
    filled_within_order: for each order o: always o.cum_qty <= o.qty;
}
