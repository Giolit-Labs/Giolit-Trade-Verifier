// The fixed version: the risk check counts the orders still open, so no sequence of fills can
// take the position past the limit.
spec PositionLimitFixed;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 500; }

strategy Accumulate {
    parameters {
        initial_position = 900;
        max_position = 1000;
    }
    rules {
        on market_update {
            buy(100, limit = market.bid);
        }
    }
}

risk_controls {
    position_cap: reject when position + open_qty(buy) + order.qty > max_position;
}

constraints {
    position_limit: always position <= max_position;
}
