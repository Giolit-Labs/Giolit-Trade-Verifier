// A venue that may still report a fill after it acknowledged a cancel (protocol option late_fills).
// The strategy re-sends what it believes was cancelled; a late fill then takes the position past
// the limit, and an order is filled after it was cancelled (constraint D).
spec LateFill;

units { price = tick(0.05 INR); money = paise; }
ranges { price 20000 .. 40000; order_qty 1 .. 500; }
protocol fix44.limit_orders { late_fills; }

strategy Requote {
    parameters { size = 100; max_position = 300; }
    rules {
        on market_update {
            if position + open_qty(buy) + size <= max_position {
                buy(size, limit = market.bid);
            }
        }
        on fill(o) {
            if position + open_qty(buy) > max_position - size {
                cancel_all();
            }
        }
    }
}

constraints {
    position_limit: always position <= max_position;
    cancel_final: for each order o: after cancelled(o): never fill(o);
}
