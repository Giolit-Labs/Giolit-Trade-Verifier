// A smart order router, fixed, working one parent buy order across two venues (NSE and BSE). On every market update it sweeps
// both books for the quantity still to buy, and the kill switch cancels the working orders.
//
// The fix of 14_smart_order_router.gts: a parent-order control counts the quantity already bought and still open at
// every venue, and the kill switch cancels every venue (again after a cancel reject).
spec SmartOrderRouterFixed;

units { price = tick(0.05 INR); money = paise; }
venues { NSE; BSE; }
ranges { price 20000 .. 40000; order_qty 1 .. 500; }
assumptions {
    market.bid < market.ask;                  // every venue's book
    market[NSE].ask within 20 ticks of market[BSE].ask;
}

strategy SweepRouter {
    parameters { target = 150; clip = 100; }
    state { remaining: qty = 150; }
    rules {
        on market_update when not kill_switch and remaining > 0 and open_qty(buy) == 0 {
            buy(min(remaining, clip), limit = market[NSE].ask, venue = NSE);
            buy(min(remaining, clip), limit = market[BSE].ask, venue = BSE);
        }
        on fill(o) { remaining -= o.last_qty; }
        on kill_switch { cancel_all(); }
        on cancel_reject(o) when kill_switch { cancel(o); }
    }
}

risk_controls {
    clip:      reject when order.qty > clip;
    venue_cap: reject when open_qty(buy, order.venue) + order.qty > clip;
    parent:    reject when order.side == buy and bought + open_qty(buy) + order.qty > target;
}

constraints {
    no_overfill:         always bought <= target;
    venue_exposure:      always open_qty(buy, NSE) <= clip and open_qty(buy, BSE) <= clip;
    no_order_after_kill: after kill_switch: never new_order;
    kill_stops_all:      for each order o: after kill_switch: always not (live(o) and not pending_cancel(o));
}
